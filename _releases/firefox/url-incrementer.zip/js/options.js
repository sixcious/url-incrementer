/**
 * URL Incrementer
 * @file options.js
 * @author Roy Six
 * @license LGPL-3.0
 */
 
var Options = (() => {

  const DOM = {},
        KEY_MODIFIERS = new Map([["Alt",0x1],["Control",0x2],["Shift",0x4],["Meta",0x8]]),
        shortcuts = ["increment", "decrement", "next", "prev", "clear", "return", "auto"];

  let backgroundPage = {},
      key = {},
      timeouts = {};

  async function init() {
    buildShortcuts();
    const ids = document.querySelectorAll("[id]"),
          i18ns = document.querySelectorAll("[data-i18n]");
    for (const element of ids) {
      DOM["#" + element.id] = element;
    }
    for (const element of i18ns) {
      element[element.dataset.i18n] = chrome.i18n.getMessage(element.id.replace(/-/g, '_').replace(/\*.*/, ''));
    }
    DOM["#internal-shortcuts-enable-button"].addEventListener("click", function() { Permissions.requestPermission("internalShortcuts", function(granted) { if (granted) { populateValuesFromStorage("internalShortcuts"); } }) });
    DOM["#browser-shortcuts-enable-button"].addEventListener("click", function() { Permissions.removePermission("internalShortcuts", function(removed) { if (removed) { populateValuesFromStorage("internalShortcuts"); } }) });
    DOM["#browser-shortcuts-quick-enable-input"].addEventListener("change", function () { chrome.storage.sync.set({"commandsQuickEnabled": this.checked}); });
    DOM["#browser-shortcuts-button"].addEventListener("click", function() { chrome.tabs.update({url: "chrome://extensions/shortcuts"}); });
    DOM["#key-quick-enable-input"].addEventListener("change", function () { chrome.storage.sync.set({"keyQuickEnabled": this.checked}); });
    DOM["#mouse-quick-enable-input"].addEventListener("change", function () { chrome.storage.sync.set({"mouseQuickEnabled": this.checked}); });
    DOM["#mouse-click-speed-input"].addEventListener("change", function () { chrome.storage.sync.set({"mouseClickSpeed": +this.value >= 100 && +this.value <= 1000 ? +this.value : 400}); });
    DOM["#icon-color-radio-dark"].addEventListener("change", changeIconColor);
    DOM["#icon-color-radio-light"].addEventListener("change", changeIconColor);
    DOM["#icon-color-radio-confetti"].addEventListener("change", changeIconColor);
    DOM["#icon-color-radio-urli"].addEventListener("change", changeIconColor);
    DOM["#icon-feedback-enable-input"].addEventListener("change", function () { chrome.storage.sync.set({"iconFeedbackEnabled": this.checked}); });
    DOM["#popup-button-size-input"].addEventListener("change", function () { if (+this.value >= 16 && +this.value <= 64) { saveInput(this, "popupButtonSize", "number");
      DOM["#popup-button-size-img"].style = "width:" + (+this.value) + "px; height:" + (+this.value) + "px;"; } });
    DOM["#popup-button-size-img"].addEventListener("click", function () { if (DOM["#popup-animations-enable-input"].checked) { UI.clickHoverCss(this, "hvr-push-click"); } });
    DOM["#popup-animations-enable-input"].addEventListener("change", function () { chrome.storage.sync.set({"popupAnimationsEnabled": this.checked});
      DOM["#popup-button-size-img"].className = this.checked ? "hvr-grow" : "" });
    DOM["#saved-urls-preselect-input"].addEventListener("change", function () { chrome.storage.local.set({"savePreselect": this.checked}); });
    DOM["#saved-urls-delete-button"].addEventListener("click", function() { deleteSavedURL(); });
    DOM["#saved-urls-wildcard-add-button"].addEventListener("click", function() { DOM["#saved-urls-wildcard"].className = "display-block fade-in"; DOM["#saved-urls-wildcard-url-textarea"].value = DOM["#saved-urls-wildcard-errors"].textContent = ""; });
    DOM["#saved-urls-wildcard-cancel-button"].addEventListener("click", function() { DOM["#saved-urls-wildcard"].className = "display-none"; });
    DOM["#saved-urls-wildcard-save-button"].addEventListener("click", function() { addSavedURL(); });
    DOM["#selection-select"].addEventListener("change", function() { DOM["#selection-custom"].className = this.value === "custom" ? "display-block fade-in" : "display-none"; chrome.storage.sync.set({"selectionPriority": this.value}); });
    DOM["#selection-custom-save-button"].addEventListener("click", function () { customSelection("save"); });
    DOM["#selection-custom-test-button"].addEventListener("click", function() { customSelection("test"); });
    DOM["#interval-input"].addEventListener("change", function () { if (+this.value > 0) { saveInput(this, "interval", "number");} });
    DOM["#leading-zeros-pad-by-detection-input"].addEventListener("change", function() { chrome.storage.sync.set({ "leadingZerosPadByDetection": this.checked}); });
    DOM["#base-select"].addEventListener("change", function() {
      DOM["#base-case"].className = +this.value > 10 ? "display-block fade-in" : "display-none";
      DOM["#base-date"].className = this.value === "date" ? "display-block fade-in" : "display-none";
      DOM["#base-custom"].className = this.value === "custom" ? "display-block fade-in" : "display-none";
      chrome.storage.sync.set({"base": +this.value > 10 ? +this.value : this.value});
    });
    DOM["#base-case-lowercase-input"].addEventListener("change", function() { chrome.storage.sync.set({"baseCase": this.value}); });
    DOM["#base-case-uppercase-input"].addEventListener("change", function() { chrome.storage.sync.set({"baseCase": this.value}); });
    DOM["#base-date-format-input"].addEventListener("input", function() { saveInput(this, "baseDateFormat", "value"); });
    DOM["#base-custom-input"].addEventListener("input", function() { saveInput(this, "baseCustom", "value"); });
    DOM["#shuffle-limit-input"].addEventListener("change", function () { if (+this.value > 0) { saveInput(this, "shuffleLimit", "number"); } });
    DOM["#error-skip-input"].addEventListener("change", function() { if (+this.value >= 0 && +this.value <= 100) { saveInput(this, "errorSkip", "number"); } });
    DOM["#error-codes-404-input"].addEventListener("change", updateErrorCodes);
    DOM["#error-codes-3XX-input"].addEventListener("change", updateErrorCodes);
    DOM["#error-codes-4XX-input"].addEventListener("change", updateErrorCodes);
    DOM["#error-codes-5XX-input"].addEventListener("change", updateErrorCodes);
    DOM["#error-codes-custom-enabled-input"].addEventListener("change", function() { chrome.storage.sync.set({"errorCodesCustomEnabled": this.checked}); DOM["#error-codes-custom"].className = this.checked ? "display-block fade-in" : "display-none"; });
    DOM["#error-codes-custom-input"].addEventListener("input", function() { saveInput(this, "errorCodesCustom", "array-split-all"); });
    DOM["#next-prev-keywords-next-textarea"].addEventListener("input", function() { saveInput(this, "nextPrevKeywordsNext", "array-split-nospace"); });
    DOM["#next-prev-keywords-prev-textarea"].addEventListener("input", function() { saveInput(this, "nextPrevKeywordsPrev", "array-split-nospace"); });
    DOM["#next-prev-links-priority-select"].addEventListener("change", function () { chrome.storage.sync.set({"nextPrevLinksPriority": this.value}); });
    DOM["#next-prev-same-domain-policy-enable-input"].addEventListener("change", function() { chrome.storage.sync.set({"nextPrevSameDomainPolicy": this.checked}); });
    DOM["#next-prev-popup-buttons-input"].addEventListener("change", function() { chrome.storage.sync.set({"nextPrevPopupButtons": this.checked}); });
    DOM["#download-enable-button"].addEventListener("click", function() { Permissions.requestPermission("download", function(granted) { if (granted) { populateValuesFromStorage("download"); } }) });
    DOM["#download-disable-button"].addEventListener("click", function() { Permissions.removePermission("download", function(removed) { if (removed) { populateValuesFromStorage("download"); } }) });
    DOM["#enhanced-mode-enable-button"].addEventListener("click", function() { Permissions.requestPermission("enhancedMode", function(granted) { if (granted) { populateValuesFromStorage("enhancedMode"); } }) });
    DOM["#enhanced-mode-disable-button"].addEventListener("click", function() { Permissions.removePermission("enhancedMode", function(removed) { if (removed) { populateValuesFromStorage("enhancedMode"); } }) });
    DOM["#urli-input"].addEventListener("click", clickURLI);
    DOM["#reset-options-button"].addEventListener("click", resetOptions);
    DOM["#manifest-name"].textContent = chrome.runtime.getManifest().name;
    DOM["#manifest-version"].textContent = chrome.runtime.getManifest().version;
    populateValuesFromStorage("all");
    backgroundPage = await Promisify.getBackgroundPage();
  }

  function buildShortcuts() {
    const table = document.getElementById("internal-shortcuts-table");
    for (const shortcut of shortcuts) {
      const row = document.createElement("div"); row.className = "row";  table.appendChild(row);
      const column1 = document.createElement("div"); column1.className = "column"; row.appendChild(column1);
      const label = document.createElement("label"); label.id = "key-" + shortcut + "-label"; label.htmlFor = "key-" + shortcut + "-input"; label.dataset.i18n = "textContent"; column1.appendChild(label);
      const column2 = document.createElement("div"); column2.className = "column"; row.appendChild(column2);
      const input = document.createElement("input");
      input.id = "key-" + shortcut + "-input";
      input.className = "key-input";
      input.type = "text";
      input.readOnly = true;
      column2.appendChild(input);
      const clear = document.createElement("input");
      clear.id = "key-" + shortcut + "-clear";
      clear.className = "key-clear";
      clear.type = "image";
      clear.src = "../img/times-circle-2.png";
      clear.alt = "key-clear";
      clear.width = clear.height = "18";
      column2.appendChild(clear);
      const column3 = document.createElement("div");
      column3.className = "column";
      row.appendChild(column3);
      const select = document.createElement("select");
      select.id = "mouse-" + shortcut + "-select";
      column3.appendChild(select);
      const optionids = ["notset", "left", "middle", "right", "right-left"];
      for (let i = 0, value = -1; i < optionids.length; i++, value++) {
        const option = document.createElement("option");
        option.id = "mouse-" + optionids[i] + "-option*" + shortcut;
        option.dataset.i18n = "textContent";
        option.value = value + "";
        select.appendChild(option);
      }
      const column4 = document.createElement("div");
      column4.className = "column";
      row.appendChild(column4);
      const clicks = document.createElement("input");
      clicks.id = "mouse-" + shortcut + "-clicks";
      clicks.style.width = "36px";
      clicks.type = "number";
      clicks.min = "1";
      clicks.max = "9";
      column4.appendChild(clicks);
      input.addEventListener("keydown", function (event) { translateKey(event); writeInput(this, key); });
      input.addEventListener("keyup", function (event) { key.code = !KEY_MODIFIERS.has(event.key) ? event.code : key.code; writeInput(this, key); setKey(this); });
      clear.addEventListener("click", function () { chrome.storage.sync.set({[getStorageKey(this)]: null}, function() { setKeyEnabled(); }); writeInput(DOM["#key-" + shortcut + "-input"], null); });
      select.addEventListener("change", function() { setMouse(this, undefined); });
      clicks.addEventListener("change", function() { setMouse(undefined, this); });
    }
  }

  async function populateValuesFromStorage(values) {
    const items = await Promisify.getItems();
    if (values === "all" || values === "internalShortcuts") {
      DOM["#browser-shortcuts"].className = !items.permissionsInternalShortcuts ? values === "internalShortcuts" ? "display-block fade-in" : "display-block" : "display-none";
      DOM["#internal-shortcuts"].className = items.permissionsInternalShortcuts ? values === "internalShortcuts" ? "display-block fade-in" : "display-block" : "display-none";
    }
    if (values === "all" || values === "download") {
      DOM["#download-disable-button"].className = items.permissionsDownload ? values === "download" ? "display-block fade-in" : "display-block" : "display-none";
      DOM["#download-enable-button"].className = !items.permissionsDownload ? values === "download" ? "display-block fade-in" : "display-block" : "display-none";
      DOM["#download-settings-enable"].className = items.permissionsDownload ? values === "download" ? "display-block fade-in" : "display-block" : "display-none";
      DOM["#download-settings-disable"].className = !items.permissionsDownload ? values === "download" ? "display-block fade-in" : "display-block" : "display-none";
    }
    if (values === "all" || values === "enhancedMode") {
      DOM["#enhanced-mode-disable-button"].className = items.permissionsEnhancedMode ? values === "enhancedMode" ? "display-block fade-in" : "display-block" : "display-none";
      DOM["#enhanced-mode-enable-button"].className = !items.permissionsEnhancedMode ? values === "enhancedMode" ? "display-block fade-in" : "display-block" : "display-none";
      DOM["#enhanced-mode-enable"].className = items.permissionsEnhancedMode ? values === "enhancedMode" ? "display-block fade-in" : "display-block" : "display-none";
      DOM["#enhanced-mode-disable"].className = !items.permissionsEnhancedMode ? values === "enhancedMode" ? "display-block fade-in" : "display-block" : "display-none";
    }
    if (values === "all" || values === "savedURLs") {
      const localItems = await Promisify.getItems("local");
      DOM["#saved-urls-delete-button"].className = localItems.saves && localItems.saves.length > 0 ? "fade-in" : "display-none";
      DOM["#saved-urls-preselect-input"].checked = localItems.savePreselect;
      buildSavedURLsSelect(localItems.saves);
    }
    if (values === "all") {
      DOM["#browser-shortcuts-quick-enable-input"].checked = items.commandsQuickEnabled;
      DOM["#key-quick-enable-input"].checked = items.keyQuickEnabled;
      DOM["#mouse-quick-enable-input"].checked = items.mouseQuickEnabled;
      DOM["#key-enable-img"].className = items.keyEnabled ? "display-inline" : "display-none";
      DOM["#mouse-enable-img"].className = items.mouseEnabled ? "display-inline" : "display-none";
      DOM["#mouse-click-speed-input"].value = items.mouseClickSpeed;
      for (const shortcut of shortcuts) {
        const keyStorageKey = getStorageKey(DOM["#key-" + shortcut + "-input"]),
              mouseStorageKey = getStorageKey(DOM["#mouse-" + shortcut + "-select"]);
        writeInput(DOM["#key-" + shortcut + "-input"], items[keyStorageKey]);
        DOM["#mouse-" + shortcut + "-select"].value = items[mouseStorageKey] ? items[mouseStorageKey].button : -1;
        DOM["#mouse-" + shortcut + "-clicks"].value = items[mouseStorageKey] ? items[mouseStorageKey].clicks : 1;
        DOM["#mouse-" + shortcut + "-clicks"].className = items[mouseStorageKey] ? "display-block fade-in" : "display-none";
      }
      DOM["#icon-color-radio-" + items.iconColor].checked = true;
      DOM["#icon-feedback-enable-input"].checked = items.iconFeedbackEnabled;
      DOM["#popup-button-size-input"].value = items.popupButtonSize;
      DOM["#popup-button-size-img"].style = "width:" + items.popupButtonSize + "px; height:" + items.popupButtonSize + "px;";
      DOM["#popup-button-size-img"].className = items.popupAnimationsEnabled ? "hvr-grow" : "";
      DOM["#popup-animations-enable-input"].checked = items.popupAnimationsEnabled;
      DOM["#selection-select"].value = items.selectionPriority;
      DOM["#selection-custom"].className = items.selectionPriority === "custom" ? "display-block" : "display-none";
      DOM["#selection-custom-url-textarea"].value = items.selectionCustom.url;
      DOM["#selection-custom-pattern-input"].value = items.selectionCustom.pattern;
      DOM["#selection-custom-flags-input"].value = items.selectionCustom.flags;
      DOM["#selection-custom-group-input"].value = items.selectionCustom.group;
      DOM["#selection-custom-index-input"].value = items.selectionCustom.index;
      DOM["#interval-input"].value = items.interval;
      DOM["#leading-zeros-pad-by-detection-input"].checked = items.leadingZerosPadByDetection;
      DOM["#base-select"].value = items.base;
      DOM["#base-case"].className = items.base > 10 ? "display-block" : "display-none";
      DOM["#base-case-lowercase-input"].checked = items.baseCase === "lowercase";
      DOM["#base-case-uppercase-input"].checked = items.baseCase === "uppercase";
      DOM["#base-date"].className = items.base === "date" ? "display-block" : "display-none";
      DOM["#base-date-format-input"].value = items.baseDateFormat;
      DOM["#base-custom"].className = items.base === "custom" ? "display-block" : "display-none";
      DOM["#base-custom-input"].value = items.baseCustom;
      DOM["#shuffle-limit-input"].value = items.shuffleLimit;
      DOM["#error-skip-input"].value = items.errorSkip;
      DOM["#error-codes-404-input"].checked = items.errorCodes.includes("404");
      DOM["#error-codes-3XX-input"].checked = items.errorCodes.includes("3XX");
      DOM["#error-codes-4XX-input"].checked = items.errorCodes.includes("4XX");
      DOM["#error-codes-5XX-input"].checked = items.errorCodes.includes("5XX");
      DOM["#error-codes-custom-enabled-input"].checked = items.errorCodesCustomEnabled;
      DOM["#error-codes-custom"].className = items.errorCodesCustomEnabled ? "display-block" : "display-none";
      DOM["#error-codes-custom-input"].value = items.errorCodesCustom;
      DOM["#next-prev-keywords-next-textarea"].value = items.nextPrevKeywordsNext;
      DOM["#next-prev-keywords-prev-textarea"].value = items.nextPrevKeywordsPrev;
      DOM["#next-prev-links-priority-select"].value = items.nextPrevLinksPriority;
      DOM["#next-prev-same-domain-policy-enable-input"].checked = items.nextPrevSameDomainPolicy;
      DOM["#next-prev-popup-buttons-input"].checked = items.nextPrevPopupButtons;
    }
  }

  function changeIconColor() {
    if (!chrome.browserAction.setIcon) {
      return;
    }
    chrome.browserAction.setIcon({
      path : {
        "16": "/img/16-" + this.value + ".png",
        "24": "/img/24-" + this.value + ".png",
        "32": "/img/32-" + this.value + ".png"
      }
    });
    chrome.storage.sync.set({"iconColor": this.value});
  }

  function translateKey(event) {
    event.preventDefault();
    key = { "modifiers":
      (event.altKey   ? KEY_MODIFIERS.get("Alt") :     0x0) |
      (event.ctrlKey  ? KEY_MODIFIERS.get("Control") : 0x0) |
      (event.shiftKey ? KEY_MODIFIERS.get("Shift") :   0x0) |
      (event.metaKey  ? KEY_MODIFIERS.get("Meta") :    0x0),
      "code": !KEY_MODIFIERS.has(event.key) ? event.code : ""
    };
  }

  function setKey(input) {
    clearTimeout(timeouts[input.id]);
    timeouts[input.id] = setTimeout(function() {
      chrome.storage.sync.set({ [getStorageKey(input)]: key }, function() { setKeyEnabled(); });
    }, 1000);
  }

  function setMouse(buttonInput, clicksInput) {
    const updateMouseEnabled = !!buttonInput;
    buttonInput = buttonInput ? buttonInput : DOM["#" + clicksInput.id.replace("clicks", "select")];
    clicksInput = clicksInput ? clicksInput : DOM["#" + buttonInput.id.replace("select", "clicks")];
    const mouse = +buttonInput.value < 0 ? null : { "button": +buttonInput.value, "clicks": +clicksInput.value};
    clicksInput.className = mouse ? "display-block fade-in" : "display-none";
    chrome.storage.sync.set({ [getStorageKey(buttonInput)]: mouse }, function() { if (updateMouseEnabled) { setMouseEnabled(); }});
  }

  function setKeyEnabled() {
    chrome.storage.sync.get(null, function(items) {
      const enabled = items.keyIncrement || items.keyDecrement || items.keyNext || items.keyPrev || items.keyClear || items.keyReturn || items.keyAuto;
      chrome.storage.sync.set({"keyEnabled": enabled}, function() {
        DOM["#key-enable-img"].className = enabled ? "display-inline" : "display-none";
      });
    });
  }

  function setMouseEnabled() {
    chrome.storage.sync.get(null, function(items) {
      const enabled =  items.mouseIncrement || items.mouseDecrement || items.mouseNext || items.mousePrev || items.mouseClear || items.mouseReturn || items.mouseAuto;
      chrome.storage.sync.set({"mouseEnabled": enabled}, function() {
        DOM["#mouse-enable-img"].className = enabled ? "display-inline" : "display-none";
      });
    });
  }

  function getStorageKey(input) {
    const regex = /(.*)-(.*)-/.exec(input.id);
    return regex[1] + regex[2][0].toUpperCase() + regex[2].substring(1);
  }

  function writeInput(input, key) {
    let text = "";
    if (!key) { text = chrome.i18n.getMessage("key_notset_option"); }
    else {
      if ((key.modifiers & KEY_MODIFIERS.get("Alt")))          { text += (text ? " + " : "") + "Alt";    }
      if ((key.modifiers & KEY_MODIFIERS.get("Control")) >> 1) { text += (text ? " + " : "") + "Ctrl";   }
      if ((key.modifiers & KEY_MODIFIERS.get("Shift"))   >> 2) { text += (text ? " + " : "") + "Shift";  }
      if ((key.modifiers & KEY_MODIFIERS.get("Meta"))    >> 3) { text += (text ? " + " : "") + "Meta";   }
      if (key.code)                                            { text += (text ? " + " : "") + key.code; }
    }
    input.value = text;
  }

  async function buildSavedURLsSelect(saves) {
    if (saves && saves.length > 0) {
      const select = document.createElement("select");
      let count = 1;
      select.id = "saved-urls-select";
      select.className = "display-block fade-in";
      for (const save of saves) {
        const output = save.type === "url" ? save.hash : save.type === "wildcard" || save.type === "regexp" ? await backgroundPage.Cryptography.decrypt(save.ciphertext, save.iv) : "";
        const option = document.createElement("option");
        option.dataset.hash = save.type === "url" ? save.hash : save.ciphertext;
        option.textContent = (count++) + " - " + save.type + ": " + output.substring(0, 16) + "..." +
          " select: " + (save.type === "url" ? save.selectionStart : save.selectionPriority) +
          " int: " + (save.interval < 100000 ? save.interval : save.interval.toString().substring(0, 4) + "...") +
          " base: " + save.base +
          " eskip: " + save.errorSkip;
        select.appendChild(option);
      }
      DOM["#saved-urls-select-div"].replaceChild(select, DOM["#saved-urls-select-div"].firstChild);
    } else {
      DOM["#saved-urls-select-div"].replaceChild(document.createElement("div"), DOM["#saved-urls-select-div"].firstChild);
    }
    DOM["#saved-urls-quantity"].textContent = " (" + (saves ? saves.length: 0) + "):";
  }

  async function addSavedURL() {
    const url = DOM["#saved-urls-wildcard-url-textarea"].value;
    if (!url || url.length < 0) {
      DOM["#saved-urls-wildcard-errors"].textContent = chrome.i18n.getMessage("saved_urls_wildcard_url_error");
      return;
    }
    const isRegExp = url.startsWith("/") && url.endsWith("/") && url.length > 1,
          urlv = isRegExp ? url.slice(1, -1) : url,
          saves = await backgroundPage.Saves.deleteSave(urlv, "addWildcard"),
          encrypt = await backgroundPage.Cryptography.encrypt(urlv),
          items = await Promisify.getItems();
    if (items.selectionCustom && items.selectionCustom.url) {
      items.selectionCustom.url = "";
    }
    saves.push({
      "type": isRegExp ? "regexp" : "wildcard", "ciphertext": encrypt.ciphertext, "iv": encrypt.iv,
      "selectionPriority": items.selectionPriority, "selectionCustom": items.selectionCustom, "interval": items.interval, "leadingZerosPadByDetection": items.leadingZerosPadByDetection,
      "base": items.base, "baseCase": items.baseCase , "baseDateFormat": items.baseDateFormat, "baseCustom": items.baseCustom,
      "errorSkip": items.errorSkip, "errorCodes": items.errorCodes, "errorCodesCustomEnabled": items.errorCodesCustomEnabled, "errorCodesCustom": items.errorCodesCustom
    });
    chrome.storage.local.set({"saves": saves}, function() {
      populateValuesFromStorage("savedURLs");
      DOM["#saved-urls-wildcard"].className = "display-none";
    });
  }

  async function deleteSavedURL() {
    const select = document.getElementById("saved-urls-select"),
          option = select.options[select.selectedIndex],
          hash = option.dataset.hash,
          saves = await Promisify.getItems("local", "saves");
    if (saves && saves.length > 0) {
      for (let i = 0; i < saves.length; i++) {
        if (saves[i].type === "url" ? saves[i].hash === hash : saves[i].ciphertext === hash) {
          saves.splice(i, 1);
          chrome.storage.local.set({saves: saves}, function() {
            populateValuesFromStorage("savedURLs");
          });
          break;
        }
      }
    }
  }

  function updateErrorCodes() {
    chrome.storage.sync.set({"errorCodes":
      [DOM["#error-codes-404-input"].checked ? DOM["#error-codes-404-input"].value : "",
       DOM["#error-codes-3XX-input"].checked ? DOM["#error-codes-3XX-input"].value : "",
       DOM["#error-codes-4XX-input"].checked ? DOM["#error-codes-4XX-input"].value : "",
       DOM["#error-codes-5XX-input"].checked ? DOM["#error-codes-5XX-input"].value : ""]
    });
  }

  function saveInput(input, storageKey, type) {
    clearTimeout(timeouts[input.id]);
    timeouts[input.id] = setTimeout(function() {
      chrome.storage.sync.set({[storageKey]:
        type === "number" ? +input.value :
        type === "value" ? input.value :
        type.startsWith("array") ? input.value ? input.value.split(type === "array-split-all" ? /[, \n]+/ : /[,\n]/).filter(Boolean) : [] : undefined
      });
    }, 1000);
  }

  async function customSelection(action) {
    const url = DOM["#selection-custom-url-textarea"].value,
          pattern = DOM["#selection-custom-pattern-input"].value,
          flags = DOM["#selection-custom-flags-input"].value,
          group = +DOM["#selection-custom-group-input"].value,
          index = +DOM["#selection-custom-index-input"].value;
    let regexp,
        matches,
        selection,
        selectionStart;
    try {
      regexp = new RegExp(pattern, flags);
      matches = regexp.exec(url);
      if (!pattern || !matches) {
        throw chrome.i18n.getMessage("selection_custom_match_error");
      }
      if (group < 0) {
        throw chrome.i18n.getMessage("selection_custom_group_error");
      }
      if (index < 0) {
        throw chrome.i18n.getMessage("selection_custom_index_error");
      }
      if (!matches[group]) {
        throw chrome.i18n.getMessage("selection_custom_matchgroup_error");
      }
      selection = matches[group].substring(index);
      if (!selection || selection === "") {
        throw chrome.i18n.getMessage("selection_custom_matchindex_error");
      }
      selectionStart = matches.index + index;
      if (selectionStart > url.length || selectionStart + selection.length > url.length) {
        throw chrome.i18n.getMessage("selection_custom_matchindex_error");
      }
      const base = isNaN(DOM["#base-select"].value) ? DOM["#base-select"].value : +DOM["#base-select"].value,
        baseCase = DOM["#base-case-uppercase-input"].checked ? DOM["#base-case-uppercase-input"].value : DOM["#base-case-lowercase-input"].checked,
        baseDateFormat = DOM["#base-date-format-input"].value,
        baseCustom = DOM["#base-custom-input"].value,
        leadingZeros = selection.startsWith("0") && selection.length > 1;
      if (backgroundPage.IncrementDecrement.validateSelection(selection, base, baseCase, baseDateFormat, baseCustom, leadingZeros)) {
        throw url.substring(selectionStart, selectionStart + selection.length) + " " + chrome.i18n.getMessage("selection_custom_matchnotvalid_error");
      }
    } catch (e) {
      DOM["#selection-custom-message-span"].textContent = e;
      return;
    }
    if (action === "test") {
      DOM["#selection-custom-message-span"].textContent = chrome.i18n.getMessage("selection_custom_test_success");
      DOM["#selection-custom-url-textarea"].setSelectionRange(selectionStart, selectionStart + selection.length);
      DOM["#selection-custom-url-textarea"].focus();
    } else if (action === "save") {
      DOM["#selection-custom-message-span"].textContent = chrome.i18n.getMessage("selection_custom_save_success");
      chrome.storage.sync.set({"selectionCustom": { "url": url, "pattern": pattern, "flags": flags, "group": group, "index": index }});
    }
  }

  function resetOptions() {
    chrome.storage.sync.clear(function() {
      chrome.storage.sync.set(backgroundPage.Background.getSDV(), function() {
        chrome.storage.local.clear(function() {
          chrome.storage.local.set(backgroundPage.Background.getLSDV(), function() {
            Permissions.removeAllPermissions();
            changeIconColor.call(DOM["#icon-color-radio-dark"]);
            populateValuesFromStorage("all");
            UI.generateAlert([chrome.i18n.getMessage("reset_options_message")]);
          });
        });
      });
    });
  }

  function clickURLI() {
    const faces = ["≧☉_☉≦", "(⌐■_■)♪", "(ᵔᴥᵔ)", "◉_◉", "(+__X)"],
          face = " " + faces[Math.floor(Math.random() * faces.length)],
          value = +this.dataset.value + 1;
    this.dataset.value = value + "";
    UI.clickHoverCss(this, "hvr-buzz-out-click");
    UI.generateAlert([value <= 10 ? value + " ..." : chrome.i18n.getMessage("urli_click_tickles") + face]);
  }

  init();

})();