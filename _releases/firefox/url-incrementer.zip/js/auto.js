/**
 * URL Incrementer
 * @file auto.js
 * @author Roy Six
 * @license LGPL-3.0
 */

var Auto = (() => {

  const autoTimers = new Map();

  let autoListenerAdded = false;

  function startAutoTimer(instance, caller) {
    if (caller === "popup") {
      instance = Background.getInstance(instance.tabId);
    }
    clearAutoTimeout(instance);
    setAutoTimeout(instance);
    addAutoListener();
    if (instance.autoRepeatCount === 0 || instance.autoBadge === "") {
      Background.setBadge(instance.tabId, "auto", false);
    } else {
      Background.setBadge(instance.tabId, "autorepeat", false);
    }
  }

  function stopAutoTimer(instance, caller) {
    clearAutoTimeout(instance);
    removeAutoListener();
    if (caller !== "tabRemovedListener") {
      if (caller !== "popupClearBeforeSet" && !instance.autoRepeat) {
        Background.setBadge(instance.tabId, "clear", true);
      } else {
        Background.setBadge(instance.tabId, "default", false);
      }
    }
  }

  function pauseOrResumeAutoTimer(instance) {
    const autoTimer = instance ? autoTimers.get(instance.tabId) : undefined;
    if (autoTimer) {
      if (!instance.autoPaused) {
        autoTimer.pause();
        instance.autoPaused = true;
        Background.setBadge(instance.tabId, "autopause", false);
      } else {
        autoTimer.resume();
        instance.autoPaused = false;
        if (instance.autoBadge === "times" && instance.autoRepeating) {
          Background.setBadge(instance.tabId, "autorepeat", false);
        } else if (instance.autoBadge === "times" && instance.autoTimes !== instance.autoTimesOriginal) {
          Background.setBadge(instance.tabId, "autotimes", false, instance.autoTimes + "");
        } else {
          Background.setBadge(instance.tabId, "auto", false);
        }
      }
      Background.setInstance(instance.tabId, instance);
      autoTimers.set(instance.tabId, autoTimer);
    }
  }

  function repeatAutoTimer(instance) {
    instance.autoRepeating = true;
    instance.autoRepeatCount++;
    Background.setInstance(instance.tabId, instance);
    startAutoTimer(instance);
  }

  function setAutoTimeout(instance) {
    const autoTimer = new AutoTimer(async function() {
      const items = await Promisify.getItems();
      if (instance.autoRepeating) {
        Action.performAction("return", "auto", instance, items);
      } else if (instance.downloadEnabled) {
        Action.performAction("download", "auto", instance, items, function(instance) {
          Action.performAction(instance.autoAction, "auto", instance, items);
        });
      } else {
        Action.performAction(instance.autoAction, "auto", instance, items);
      }
    }, instance.autoSeconds * 1000);
    autoTimers.set(instance.tabId, autoTimer);
  }

  function clearAutoTimeout(instance) {
    const autoTimer = instance ? autoTimers.get(instance.tabId) : undefined;
    if (autoTimer) {
      autoTimer.clear();
      autoTimers.delete(instance.tabId);
    }
  }

  function setAutoWait(instance, wait) {
    const autoTimer = instance ? autoTimers.get(instance.tabId) : undefined;
    if (autoTimer) {
      autoTimer.setWait(wait);
      autoTimers.set(instance.tabId, autoTimer);
    }
  }

  function addAutoListener() {
    if (!autoListenerAdded) {
      chrome.tabs.onUpdated.addListener(autoListener);
      autoListenerAdded = true;
    }
  }

  function removeAutoListener() {
    if (![...Background.getInstances().values()].some(instance => instance && instance.autoEnabled)) {
      chrome.tabs.onUpdated.removeListener(autoListener);
      autoListenerAdded = false;
    }
  }

  function autoListener(tabId, changeInfo, tab) {
    const loading = changeInfo.status === "loading",
          complete = changeInfo.status === "complete";
    if (!loading && !complete) {
      return;
    }
    const instance = Background.getInstance(tabId);
    if (instance && instance.autoEnabled) {
      if (loading) {
        if (instance.autoWait) {
          setAutoWait(instance, true);
        }
        if (instance.autoPaused) {
          Background.setBadge(tabId, "autopause", false);
        } else if (instance.autoBadge === "times") {
          Background.setBadge(tabId, "autotimes", false, (instance.autoTimes) + "");
        } else {
          Background.setBadge(tabId, "auto", false);
        }
      }
      if (instance.autoWait ? complete : loading) {
        if (instance.autoWait) {
          setAutoWait(instance, false);
        }
        if (instance.autoPaused) {
          if (instance.autoTimes <= 0) {
            Action.performAction("clear", "auto", instance);
          }
        }
        else if (instance.autoTimes > 0) {
          clearAutoTimeout(instance);
          setAutoTimeout(instance);
        } else {
          Action.performAction("clear", "auto", instance);
        }
      }
    } else if (complete) {
      removeAutoListener();
    }
  }

  function AutoTimer(callback, delay) {
    let timeout,
        start,
        remaining = delay,
        wait = false;

    this.pause = function() {
      clearTimeout(timeout);
      remaining -= Date.now() - start;
      remaining = remaining < 0 || wait ? delay : remaining;
    };

    this.resume = function() {
      start = Date.now();
      clearTimeout(timeout);
      timeout = wait ? timeout : setTimeout(callback, remaining);
    };

    this.clear = function() {
      clearTimeout(timeout);
    };

    this.setWait = function(wait_) {
      wait = wait_;
    };

    this.resume();
  }

  return {
    startAutoTimer: startAutoTimer,
    stopAutoTimer: stopAutoTimer,
    pauseOrResumeAutoTimer: pauseOrResumeAutoTimer,
    repeatAutoTimer: repeatAutoTimer
  };

})();