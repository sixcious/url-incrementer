/**
 * URL Incrementer
 * @file ui.js
 * @author Roy Six
 * @license LGPL-3.0
 */

var UI = (() => {

  function generateAlert(messages, callback) {
    const div = document.createElement("div"),
          ul = document.createElement("ul");
    div.classList.add("overlay");
    for (const message of messages) {
      const li = document.createElement("li");
      li.appendChild(document.createTextNode(message));
      ul.appendChild(li);
    }
    div.appendChild(ul);
    document.body.appendChild(div);
    setTimeout(function () { div.classList.add("overlay-visible"); }, 10);
    setTimeout(function () { div.classList.remove("overlay-visible"); document.body.removeChild(div); if (callback) { callback(); } }, 4000);
  }

  function clickHoverCss(el, effect) {
    el.classList.remove(effect);
    setTimeout(function () { el.classList.add(effect); }, 50);
  }

  return {
    generateAlert: generateAlert,
    clickHoverCss: clickHoverCss
  };

})();