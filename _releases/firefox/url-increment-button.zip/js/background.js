/**
 * URL Increment Button
 * @file background.js
 * @author Roy Six
 * @license LGPL-3.0
 */

var Background = (() => {

  const URL_INCREMENTER_EXTENSION_ID = "url-incrementer@webextensions";

  async function clickListener(tab) {
    chrome.runtime.sendMessage(URL_INCREMENTER_EXTENSION_ID, {"greeting": "performAction", "action": "increment", "tab": tab});
  }

  chrome.browserAction.onClicked.addListener(clickListener);

})();