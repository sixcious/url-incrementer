/**
 * URL Incrementer
 * @file promisify.js
 * @author Roy Six
 * @license LGPL-3.0
 */

var Promisify = (() => {

  function getItems(namespace = "sync", key = null) {
    return new Promise(resolve => {
      chrome.storage[namespace].get(key, items => {
        key ? resolve(items[key]) : resolve(items);
      });
    });
  }

  function getTabs(queryInfo = {active: true, lastFocusedWindow: true}) {
    return new Promise(resolve => {
      chrome.tabs.query(queryInfo, tabs => {
        resolve(tabs);
      });
    });
  }

  function getBackgroundPage() {
    return new Promise(resolve => {
      chrome.runtime.getBackgroundPage(backgroundPage => {
        resolve(backgroundPage);
      });
    });
  }

  return {
    getItems: getItems,
    getTabs: getTabs,
    getBackgroundPage: getBackgroundPage
  };

})();