/**
 * URL Incrementer
 * @file background.js
 * @author Roy Six
 * @license LGPL-3.0
 */

var Background = (() => {

  const STORAGE_DEFAULT_VALUES = {
    "permissionsInternalShortcuts": true, "permissionsDownload": false, "permissionsEnhancedMode": true,
    "iconColor": "dark", "iconFeedbackEnabled": false,
    "popupButtonSize": 32, "popupAnimationsEnabled": true,
    "commandsQuickEnabled": true,
    "keyEnabled": true, "keyQuickEnabled": true, "keyIncrement": {"modifiers": 6, "code": "ArrowUp"}, "keyDecrement": {"modifiers": 6, "code": "ArrowDown"}, "keyNext": {"modifiers": 6, "code": "ArrowRight"}, "keyPrev": {"modifiers": 6, "code": "ArrowLeft"}, "keyClear": {"modifiers": 6, "code": "KeyX"}, "keyReturn": {"modifiers": 6, "code": "KeyZ"}, "keyAuto": {"modifiers": 6, "code": "Space"},
    "mouseEnabled": true, "mouseQuickEnabled": true, "mouseClickSpeed": 400, "mouseIncrement": {"button": 3, "clicks": 2}, "mouseDecrement": {"button": 3, "clicks": 3}, "mouseNext": null, "mousePrev": null, "mouseClear": null, "mouseReturn": null, "mouseAuto": null,
    "interval": 1, "shuffleLimit": 1000, "leadingZerosPadByDetection": true,
    "base": 10, "baseCase": "lowercase", "baseDateFormat": "", "baseCustom": "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz",
    "selectionPriority": "prefixes", "selectionCustom": { "url": "", "pattern": "", "flags": "", "group": 0, "index": 0 },
    "errorSkip": 0, "errorCodes": ["404", "", "", ""], "errorCodesCustomEnabled": false, "errorCodesCustom": [],
    "nextPrevLinksPriority": "attributes", "nextPrevSameDomainPolicy": true, "nextPrevPopupButtons": false,
    "nextPrevKeywordsNext": ["pnnext", "next page", "next", "newer", "forward", "次", "&gt;", ">", "›", "→"],
    "nextPrevKeywordsPrev": ["pnprev", "previous page", "prev", "previous", "older", "前", "&lt;", "<", "‹", "←"],
    "autoAction": "increment", "autoTimes": 10, "autoSeconds": 5, "autoWait": true, "autoBadge": "auto",
    "downloadStrategy": "extensions", "downloadExtensions": [], "downloadTags": [], "downloadAttributes": [], "downloadSelector": "", "downloadIncludes": [], "downloadExcludes": [], "downloadPreview": ["thumb", "extension", "tag", "url", "compressed"],
    "toolkitTool": "crawl", "toolkitAction": "increment", "toolkitQuantity": 10, "toolkitSeconds": 2
  },

  LOCAL_STORAGE_DEFAULT_VALUES = {
    "saves": [], "savePreselect": false
  },

  BROWSER_ACTION_BADGES = {
    "incrementm": { "text": "+",    "backgroundColor": "#4AACED" },
    "decrementm": { "text": "-",    "backgroundColor": "#4AACED" },
    "increment":  { "text": "+",    "backgroundColor": "#1779BA" },
    "decrement":  { "text": "-",    "backgroundColor": "#1779BA" },
    "increment2": { "text": "+",    "backgroundColor": "#004687" },
    "decrement2": { "text": "-",    "backgroundColor": "#004687" },
    "increment3": { "text": "+",    "backgroundColor": "#001354" },
    "decrement3": { "text": "-",    "backgroundColor": "#001354" },
    "next":       { "text": ">",    "backgroundColor": "#05854D" },
    "prev":       { "text": "<",    "backgroundColor": "#05854D" },
    "clear":      { "text": "X",    "backgroundColor": "#FF0000" },
    "return":     { "text": "RET", "backgroundColor": "#FFCC22" },
    "auto":       { "text": "AUTO", "backgroundColor": "#FF6600" },
    "autotimes":  { "text": "",     "backgroundColor": "#FF6600" },
    "autopause":  { "text": "❚❚",    "backgroundColor": "#FF6600" },
    "autorepeat": { "text": "REP",  "backgroundColor": "#FF6600" },
    "download":   { "text": "DL",   "backgroundColor": "#663399" },
    "toolkit":    { "text": "TOOL", "backgroundColor": "#000028" },
    "skip":       { "text": "SKIP", "backgroundColor": "#000000" },
    "default":    { "text": "",     "backgroundColor": [0,0,0,0] }
  },

  instances = new Map();

  let persistent = false;

  function getSDV() {
    return STORAGE_DEFAULT_VALUES;
  }

  function getLSDV() {
    return LOCAL_STORAGE_DEFAULT_VALUES;
  }

  function getInstances() {
    return instances;
  }

  function getInstance(tabId) {
    return instances.get(tabId);
  }

  function setInstance(tabId, instance) {
    instances.set(tabId, JSON.parse(JSON.stringify(instance)));
    if (!persistent) {
      makePersistent();
    }
  }

  function deleteInstance(tabId) {
    instances.delete(tabId);
  }

  async function buildInstance(tab, items, localItems) {
    items = items ? items : await Promisify.getItems();
    localItems = localItems ? localItems : await Promisify.getItems("local");
    const saves = localItems.saves;
    let via = "items",
        object = items,
        selection = IncrementDecrement.findSelection(tab.url, items.selectionPriority, items.selectionCustom);
    for (const save of saves) {
      const result = await Saves.matchesSave(save, tab.url);
      if (result.matches) {
        via = save.type;
        object = save;
        selection = save.type === "url" ? result.selection : IncrementDecrement.findSelection(tab.url, save.selectionPriority, save.selectionCustom);
        break;
      }
    }
    return {
      "enabled": false, "autoEnabled": false, "downloadEnabled": false, "toolkitEnabled": false, "multiEnabled": false,
      "tabId": tab.id, "url": tab.url,
      "saveFound": via !== "items", "saveType": via === "items" ? "none" : via,
      "selection": selection.selection, "selectionStart": selection.selectionStart,
      "leadingZeros": via === "url" ? object.leadingZeros : object.leadingZerosPadByDetection && selection.selection.charAt(0) === '0' && selection.selection.length > 1,
      "interval": object.interval,
      "base": object.base, "baseCase": object.baseCase, "baseDateFormat": object.baseDateFormat, "baseCustom": object.baseCustom,
      "errorSkip": object.errorSkip, "errorCodes": object.errorCodes, "errorCodesCustomEnabled": object.errorCodesCustomEnabled, "errorCodesCustom": object.errorCodesCustom,
      "multi": {"1": {}, "2": {}, "3": {}}, "multiCount": 0,
      "urls": [], "shuffleURLs": false, "shuffleLimit": items.shuffleLimit,
      "nextPrevLinksPriority": items.nextPrevLinksPriority, "nextPrevSameDomainPolicy": items.nextPrevSameDomainPolicy,
      "autoAction": items.autoAction, "autoTimes": items.autoTimes, "autoSeconds": items.autoSeconds, "autoWait": items.autoWait, "autoBadge": items.autoBadge, "autoPaused": false, "autoRepeat": false, "autoRepeating": false, "autoRepeatCount": 0,
      "downloadStrategy": items.downloadStrategy, "downloadExtensions": items.downloadExtensions, "downloadTags": items.downloadTags, "downloadAttributes": items.downloadAttributes, "downloadSelector": items.downloadSelector,
      "downloadIncludes": items.downloadIncludes, "downloadExcludes": items.downloadExcludes,
      "downloadPreview": items.downloadPreview,
      "toolkitTool": items.toolkitTool, "toolkitAction": items.toolkitAction, "toolkitQuantity": items.toolkitQuantity, "toolkitSeconds": items.toolkitSeconds
    };
  }

  function setBadge(tabId, badge, temporary, text, backgroundColor) {
    if (!chrome.browserAction.setBadgeText || !chrome.browserAction.setBadgeBackgroundColor) {
      return;
    }
    chrome.browserAction.setBadgeText({text: text ? text : BROWSER_ACTION_BADGES[badge].text, tabId: tabId});
    chrome.browserAction.setBadgeBackgroundColor({color: backgroundColor ? backgroundColor : BROWSER_ACTION_BADGES[badge].backgroundColor, tabId: tabId});
    if (temporary) {
      setTimeout(function () {
        chrome.browserAction.setBadgeText({text: BROWSER_ACTION_BADGES["default"].text, tabId: tabId});
        chrome.browserAction.setBadgeBackgroundColor({color: BROWSER_ACTION_BADGES["default"].backgroundColor, tabId: tabId});
      }, 2000);
    }
  }

  async function installedListener(details) {
    if (details.reason === "install" || (details.reason === "update" && details.previousVersion >= "1.0" && details.previousVersion < "6.0")) {
      const items = details.previousVersion && details.previousVersion >= "5.3" ? await Promisify.getItems() : undefined;
      chrome.storage.sync.clear(function() {
        chrome.storage.sync.set(STORAGE_DEFAULT_VALUES, function() {
          chrome.storage.local.clear(function() {
            chrome.storage.local.set(LOCAL_STORAGE_DEFAULT_VALUES, function() {
              if (details.reason === "install") {
                chrome.runtime.openOptionsPage();
              } else if (details.previousVersion >= "1.0" && details.previousVersion <= "5.2") {
                Permissions.removeAllPermissions();
              } else if (details.previousVersion >= "5.3" && details.previousVersion <= "5.8") {
                chrome.storage.sync.set({"TODO": "TODO"});
              }
            });
          });
        });
      });
    }
    startupListener();
  }

  async function startupListener() {
    const items = await Promisify.getItems();
    if (chrome.browserAction.setIcon && items && ["default", "light", "confetti", "urli"].includes(items.iconColor)) {
      chrome.browserAction.setIcon({
        path : {
          "16": "/img/16-" + items.iconColor + ".png",
          "24": "/img/24-" + items.iconColor + ".png",
          "32": "/img/32-" + items.iconColor + ".png"
        }
      });
    }
    if (items && items.permissionsInternalShortcuts) {
      Permissions.checkDeclarativeContent();
    }
  }

  async function messageListener(request, sender, sendResponse) {
    sender.tab.url = sender.url;
    if (request && request.greeting === "performAction") {
      const items = await Promisify.getItems();
      const instance = getInstance(sender.tab.id) || await buildInstance(sender.tab, items);
      if ((request.shortcut === "key" && items.keyEnabled && (items.keyQuickEnabled || (instance && (instance.enabled || instance.saveFound)))) ||
        (request.shortcut === "mouse" && items.mouseEnabled && (items.mouseQuickEnabled || (instance && (instance.enabled || instance.saveFound))))) {
        Action.performAction(request.action, "message", instance, items);
      }
    }
  }

  async function messageExternalListener(request, sender, sendResponse) {
    const URL_INCREMENT_BUTTON_EXTENSION_ID = "url-increment-button@webextensions",
          URL_DECREMENT_BUTTON_EXTENSION_ID = "url-decrement-button@webextensions";
    if (sender && (sender.id === URL_INCREMENT_BUTTON_EXTENSION_ID || sender.id === URL_DECREMENT_BUTTON_EXTENSION_ID) &&
        request && request.tab && (request.action === "increment" || request.action === "decrement")) {
      sendResponse({received: true});
      const items = await Promisify.getItems();
      const instance = getInstance(request.tab.id) || await buildInstance(request.tab, items);
      Action.performAction(request.action, "external", instance, items);
    }
  }

  async function commandListener(command) {
    if (command === "increment" || command === "decrement" || command === "next" || command === "prev" || command === "clear" || command === "return" || command === "auto")  {
      const items = await Promisify.getItems();
      if (!items.permissionsInternalShortcuts) {
        const tabs = await Promisify.getTabs();
        if (tabs && tabs[0]) {
          const instance = getInstance(tabs[0].id) || await buildInstance(tabs[0], items);
          if (items.commandsQuickEnabled || (instance && (instance.enabled || instance.saveFound))) {
            Action.performAction(command, "command", instance, items);
          }
        }
      }
    }
  }

  async function makePersistent() {
    const tabs = await Promisify.getTabs({}),
          tabIds = tabs.map(tab => tab.id);
    [...instances.keys()].forEach(function(key) {
      if (!tabIds.includes(key)) {
        Action.performAction("clear", "tabRemovedListener", getInstance(key));
      }
    });
    if ([...instances.values()].some(instance => instance && instance.enabled)) {
      persistent = true;
      setTimeout(makePersistent, 3000);
    } else {
      persistent = false;
    }
  }

  chrome.runtime.onInstalled.addListener(installedListener);
  chrome.runtime.onStartup.addListener(startupListener);
  chrome.runtime.onMessage.addListener(messageListener);
  chrome.runtime.onMessageExternal.addListener(messageExternalListener);
  if (chrome.commands) { chrome.commands.onCommand.addListener(commandListener); }

  return {
    getSDV: getSDV,
    getLSDV: getLSDV,
    getInstances: getInstances,
    getInstance: getInstance,
    setInstance: setInstance,
    deleteInstance: deleteInstance,
    buildInstance: buildInstance,
    setBadge: setBadge
  };

})();