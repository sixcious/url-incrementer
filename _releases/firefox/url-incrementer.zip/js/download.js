/**
 * URL Incrementer
 * @file download.js
 * @author Roy Six
 * @license LGPL-3.0
 */
 
var Download = (() => {

  const URL_ATTRIBUTES = ["action", "cite", "data", "formaction", "href", "icon", "manifest", "poster", "src", "style", "usemap"];

  function previewDownloadURLs() {
    const pageURL = findDownloadURLs("page"),
          allURLs = findDownloadURLs("all"),
          allExtensions = findProperties(allURLs, "extension"),
          allTags = findProperties(allURLs, "tag"),
          allAttributes = findProperties(allURLs, "attribute");
    return { "pageURL": pageURL, "allURLs": allURLs, "allExtensions": allExtensions, "allTags": allTags, "allAttributes": allAttributes }
  }

  function findDownloadURLs(strategy, extensions, tags, attributes, selector, includes, excludes) {
    const items = new Map();
    let results = [],
        selectorbuilder = "";
    switch (strategy) {
      case "all":
      case "extensions":
        for (const urlattribute of URL_ATTRIBUTES) {
          selectorbuilder += (selectorbuilder !== "" ? "," : "") + "[" + urlattribute + "]";
        }
        break;
      case "tags":
        for (const tag of tags) {
          selectorbuilder += (selectorbuilder !== "" ? "," : "") + tag;
        }
        break;
      case "attributes":
        for (const attribute of attributes) {
          selectorbuilder += (selectorbuilder !== "" ? "," : "") + "[" + attribute + "]";
        }
        break;
      case "selector":
        selectorbuilder = selector;
        break;
      case "page":
        break;
      default:
        break;
    }
    try {
      if (strategy === "page") {
        results = findPageURL(includes, excludes, items);
      } else {
        results = findDownloadURLsBySelector(document, strategy, extensions, tags, attributes, selectorbuilder, includes, excludes, items);
      }
    } catch (e) {
      results = [];
    }
    return results;
  }

  function findPageURL(includes, excludes, items) {
    const url = window.location.href;
    buildItems(items, undefined, "", url, "page", undefined, undefined, undefined, undefined, includes, excludes);
    return [...items.values()];
  }

  function findDownloadURLsBySelector(document, strategy, extensions, tags, attributes, selector, includes, excludes, items) {
    const elements = document.querySelectorAll(selector),
          origin = new URL(window.location.href).origin;
    for (const element of elements) {
      for (const attribute of URL_ATTRIBUTES) {
        if (element[attribute]) {
          if (attribute && attribute.toLowerCase() === "style") {
            const urls = extractURLsFromStyle(element.style);
            for (const url of urls) {
              buildItems(items, element, attribute, url, strategy, extensions, tags, attributes, selector, includes, excludes);
            }
          }
          else if (element.tagName && element.tagName.toLowerCase() === "iframe" && attribute && attribute.toLowerCase() === "src") {
            const url = element[attribute];
            buildItems(items, element, attribute, url, strategy, extensions, tags, attributes, selector, includes, excludes);
            if (isValidURL(url) && new URL(url).origin === origin && element.contentWindow && element.contentWindow.document) {
              findDownloadURLsBySelector(element.contentWindow.document, strategy, extensions, tags, attributes, selector, includes, excludes, items);
            }
          } else {
            const url = element[attribute];
            buildItems(items, element, attribute, url, strategy, extensions, tags, attributes, selector, includes, excludes);
          }
        }
      }
    }
    return [...items.values()];
  }

  function buildItems(items, element, attribute, url, strategy, extensions, tags, attributes, selector, includes, excludes) {
    let filenameAndExtension = "",
        filename = "",
        extension = "",
        tag = "";
    if (isValidURL(url) && doesIncludeOrExclude(url, includes, true) && doesIncludeOrExclude(url, excludes, false)) {
      filenameAndExtension = findFilenameAndExtension(url);
      filename = findFilename(filenameAndExtension);
      extension = findExtension(filenameAndExtension);
      if (strategy === "extensions" && (!extension || !extensions.includes(extension))) {
        return;
      }
      tag = element && element.tagName ? element.tagName.toLowerCase() : "";
      if (strategy === "tags" && (!tag || !tags.includes(tag))) {
        return;
      }
      if (strategy === "attributes" && (!attribute || !attributes.includes(attribute))) {
        return;
      }
      items.set(url + "", {"url": url, "filenameAndExtension": filenameAndExtension, "filename": filename, "extension": extension, "tag": tag, "attribute": attribute});
    }
  }

  function findProperties(items, property) {
    const properties = new Set();
    if (items) {
      for (const item of items) {
        if (item && item[property]) {
          properties.add(item[property]);
        }
      }
    }
    return [...properties].sort();
  }

  function doesIncludeOrExclude(url, terms, doesInclude) {
    let does = true;
    if (terms && terms.length > 0) {
      for (const term of terms) {
        if (term && doesInclude ? !url.includes(term) : url.includes(term)) {
          does = false;
          break;
        }
      }
    }
    return does;
  }

  function extractURLsFromStyle(style) {
    const urls = [];
    if (style) {
      const URL_STYLE_PROPERTIES =  ["background", "background-image", "list-style", "list-style-image", "content", "cursor", "play-during", "cue", "cue-after", "cue-before", "border-image", "border-image-source", "mask", "mask-image", "@import", "@font-face"],
            regex =  /\s*url\s*\(\s*(?:'(\S*?)'|"(\S*?)"|((?:\\\s|\\\)|\\\"|\\\'|\S)*?))\s*\)/i;
      for (const property of URL_STYLE_PROPERTIES) {
        if (style[property]) {
          const match = regex.exec(style[property]);
          const url = match ? match[2] ? match[2] : "" : "";
          urls.push(url);
        }
      }
    }
    return urls;
  }

  function findFilenameAndExtension(url) {
    let filenameAndExtension = "";
    if (url) {
      filenameAndExtension = url.split('#').shift().split('?').shift().split('/').pop();
    }
    return filenameAndExtension;
  }

  function findFilename(filenameAndExtension) {
    let filename = "";
    if (filenameAndExtension) {
      filename = filenameAndExtension.split('.').shift();
    }
    return filename;
  }

  function findExtension(filenameAndExtension) {
    let extension = "";
    if (filenameAndExtension && filenameAndExtension.includes(".")) {
      extension = filenameAndExtension.split('.').pop();
      if (!isValidExtension(extension)) {
        extension = "";
      }
    }
    return extension;
  }

  function isValidURL(url) {
    return url && typeof url === "string" && url.trim().length > 0 && !url.startsWith("mailto");
  }

  function isValidExtension(extension) {
    return extension && extension.trim().length > 0 && /^[a-z0-9\\.]+$/i.test(extension) && extension.length <= 8;
  }

  return {
    previewDownloadURLs: previewDownloadURLs,
    findDownloadURLs: findDownloadURLs
  };

})();