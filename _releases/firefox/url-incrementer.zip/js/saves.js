/**
 * URL Incrementer
 * @file saves.js
 * @author Roy Six
 * @license LGPL-3.0
 */
 
var Saves = (() => {

  async function addURL(instance) {
    const saves = await deleteSave(instance.url, "addURL"),
          url1 = instance.url.substring(0, instance.selectionStart),
          url2 = instance.url.substring(instance.selectionStart + instance.selection.length),
          salt = Cryptography.salt(),
          hash = await Cryptography.hash(url1 + url2, salt);
    saves.unshift({
      "type": "url", "hash": hash, "salt": salt, "selectionEnd": url2.length,
      "selectionStart": instance.selectionStart, "interval": instance.interval, "leadingZeros": instance.leadingZeros,
      "base": instance.base, "baseCase": instance.baseCase, "baseDateFormat": instance.baseDateFormat, "baseCustom": instance.baseCustom,
      "errorSkip": instance.errorSkip, "errorCodes": instance.errorCodes, "errorCodesCustomEnabled": instance.errorCodesCustomEnabled, "errorCodesCustom": instance.errorCodesCustom
    });
    chrome.storage.local.set({"saves": saves});
  }

  async function deleteSave(url, caller) {
    const saves = await Promisify.getItems("local", "saves");
    for (let i = 0; i < saves.length; i++) {
      const result = await matchesSave(saves[i], url);
      if (result.matches) {
        saves.splice(i, 1);
        break;
      }
    }
    if (caller === "addURL" || caller === "addWildcard") {
      return saves;
    } else {
      chrome.storage.local.set({"saves": saves});
    }
  }

  async function matchesSave(save, url) {
    let result = { matches: false };
    if (save && url) {
      if (save.type === "url") {
        result = await matchesURL(save, url);
      } else if (save.type === "wildcard") {
        result = await matchesWildcard(save, url);
      } else if (save.type === "regexp") {
        result = await matchesRegExp(save, url);
      }
    }
    return result;
  }

  async function matchesURL(save, url) {
    const url1 = url.substring(0, save.selectionStart),
          url2 = url.substring(url.length - save.selectionEnd),
          hash = await Cryptography.hash(url1 + url2, save.salt),
          selection = url.substring(save.selectionStart, url2 ? url.lastIndexOf(url2) : url.length);
    const matches = hash === save.hash && IncrementDecrement.validateSelection(selection, save.base, save.baseCase, save.baseDateFormat, save.baseCustom, save.leadingZeros) === "";
    return { matches: matches, selection: { selection: selection, selectionStart: save.selectionStart } };
  }

  async function matchesWildcard(save, url) {
    const wildcard = await Cryptography.decrypt(save.ciphertext, save.iv),
          matches = url.includes(wildcard);
    return { matches: matches };
  }

  async function matchesRegExp(save, url) {
    const regexp = await Cryptography.decrypt(save.ciphertext, save.iv),
          matches = new RegExp(regexp).exec(url);
    return { matches: matches };
  }

  return {
    addURL: addURL,
    deleteSave: deleteSave,
    matchesSave: matchesSave
  };

})();