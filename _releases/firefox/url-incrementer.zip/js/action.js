/**
 * URL Incrementer
 * @file action.js
 * @author Roy Six
 * @license LGPL-3.0
 */

 var Action = (() => {

  async function performAction(action, caller, instance, items, callback) {
    items = items ? items : await Promisify.getItems();
    let actionPerformed = false;
    if (instance.autoEnabled) {
      instance = Background.getInstance(instance.tabId) || instance;
      if (instance.autoAction === action) {
        instance.autoTimes--;
      } else if ((instance.autoTimes < instance.autoTimesOriginal) &&
        ((instance.autoAction === "increment" || instance.autoAction === "decrement") && (action === "increment" || action === "decrement")) ||
        ((instance.autoAction === "next" || instance.autoAction === "prev") && (action === "next" || action === "prev"))) {
        instance.autoTimes++;
      }
      if (instance.autoTimes < 0) {
        action = "clear";
      }
    }
    if (instance.downloadEnabled && ["increment", "decrement", "next", "prev"].includes(action)) {
      chrome.tabs.onUpdated.addListener(function downloadPreviewListener(tabId, changeInfo, tab) {
        if (changeInfo.status === "complete") {
          chrome.runtime.sendMessage({greeting: "updatePopupDownloadPreview", instance: instance}, function(response) { if (chrome.runtime.lastError) {} });
          chrome.tabs.onUpdated.removeListener(downloadPreviewListener);
        }
      });
    }
    switch (action) {
      case "increment":  case "decrement":
      case "increment1": case "decrement1":
      case "increment2": case "decrement2":
      case "increment3": case "decrement3":
        actionPerformed = incrementDecrement(action, instance, items);
        break;
      case "next": case "prev":
        actionPerformed = nextPrev(action, instance, items);
        break;
      case "clear":
        actionPerformed = clear(caller, instance, items, callback);
        break;
      case "return":
        actionPerformed = returnToStart(caller, instance);
        break;
      case "toolkit":
        actionPerformed = toolkit(instance);
        break;
      case "auto":
        actionPerformed = auto(instance);
        break;
      case "download":
        actionPerformed = download(instance, callback);
        break;
      default:
        break;
    }
    if (items.iconFeedbackEnabled && actionPerformed && !(instance.autoEnabled || (caller === "auto" && instance.autoRepeat) || caller === "popupClearBeforeSet" || caller === "tabRemovedListener")) {
      action = instance.multiEnabled ? action === "increment" || action === "decrement" ? action + "m" : action === "increment1" || action === "decrement1" ? action.slice(0, -1) : action : action;
      Background.setBadge(instance.tabId, action, true);
    }
  }

  function updateTab(instance) {
    chrome.tabs.update(instance.tabId, {url: instance.url});
    if (instance.enabled) {
      Background.setInstance(instance.tabId, instance);
    }
    chrome.runtime.sendMessage({greeting: "updatePopupInstance", instance: instance}, function(response) { if (chrome.runtime.lastError) {} });
  }

  function incrementDecrement(action, instance, items) {
    let actionPerformed = false;
    if ((instance.selection !== "" && instance.selectionStart >= 0) || (instance.urls && instance.urls.length > 0)) {
      actionPerformed = true;
      if ((instance.errorSkip > 0 && (instance.errorCodes && instance.errorCodes.length > 0) ||
          (instance.errorCodesCustomEnabled && instance.errorCodesCustom && instance.errorCodesCustom.length > 0)) &&
          (items.permissionsEnhancedMode)) {
        incrementDecrementErrorSkip(action, instance, instance.errorSkip);
      }
      else {
        IncrementDecrement.incrementDecrement(action, instance);
        updateTab(instance);
      }
    }
    return actionPerformed;
  }

  function incrementDecrementErrorSkip(action, instance, errorSkipRemaining) {
    IncrementDecrement.incrementDecrement(action, instance);
    if (errorSkipRemaining > 0) {
      fetch(instance.url, { method: "HEAD", credentials: "same-origin" }).then(function(response) {
        if (response && response.status &&
          ((instance.errorCodes && (
            (instance.errorCodes.includes("404") && response.status === 404) ||
            (instance.errorCodes.includes("3XX") && ((response.status >= 300 && response.status <= 399) || response.redirected)) ||
            (instance.errorCodes.includes("4XX") && response.status >= 400 && response.status <= 499) ||
            (instance.errorCodes.includes("5XX") && response.status >= 500 && response.status <= 599))) ||
            (instance.errorCodesCustomEnabled && instance.errorCodesCustom &&
            (instance.errorCodesCustom.includes(response.status + "") || (response.redirected && ["301", "302", "303", "307", "308"].some(redcode => instance.errorCodesCustom.includes(redcode))))))) {
          if (!instance.autoEnabled) {
            Background.setBadge(instance.tabId, "skip", true, response.redirected ? "RED" : response.status + "");
          }
          incrementDecrementErrorSkip(action, instance, errorSkipRemaining - 1);
        } else {
          updateTab(instance);
        }
      }).catch(e => {
        if (!instance.autoEnabled) {
          Background.setBadge(instance.tabId, "skip", true, "ERR");
        }
        incrementDecrementErrorSkip(action, instance, errorSkipRemaining - 1);
      });
    } else {
      updateTab(instance);
    }
  }

  function nextPrev(action, instance, items) {
    let actionPerformed = true;
    chrome.tabs.executeScript(instance.tabId, {file: "/js/next-prev.js", runAt: "document_end"}, function() {
      const code = "NextPrev.findNextPrevURL(" +
        JSON.stringify(action === "next" ? items.nextPrevKeywordsNext : items.nextPrevKeywordsPrev) + "," +
        JSON.stringify(items.nextPrevLinksPriority) + ", " +
        JSON.stringify(items.nextPrevSameDomainPolicy) + ");";
      chrome.tabs.executeScript(instance.tabId, {code: code, runAt: "document_end"}, function(results) {
        if (results && results[0]) {
          if (instance.autoEnabled && (instance.autoAction === "next" || instance.autoAction === "prev")) {
            instance.url = results[0];
            updateTab(instance);
          } else {
            chrome.tabs.update(instance.tabId, {url: results[0]});
          }
        }
      });
    });
    return actionPerformed;
  }

  function clear(caller, instance, items, callback) {
    let actionPerformed = false;
    if (instance.autoEnabled && instance.autoRepeat && caller === "auto") {
      Auto.repeatAutoTimer(JSON.parse(JSON.stringify(instance)));
      return actionPerformed;
    }
    if (instance.enabled || instance.autoEnabled || instance.downloadEnabled) {
      actionPerformed = true;
    }
    Background.deleteInstance(instance.tabId);
    if (caller !== "popupClearBeforeSet" && caller !== "tabRemovedListener" && caller !== "auto") {
      if (items.permissionsInternalShortcuts && items.keyEnabled && !items.keyQuickEnabled) {
        chrome.tabs.sendMessage(instance.tabId, {greeting: "removeKeyListener"});
      }
      if (items.permissionsInternalShortcuts && items.mouseEnabled && !items.mouseQuickEnabled) {
        chrome.tabs.sendMessage(instance.tabId, {greeting: "removeMouseListener"});
      }
      if (!instance.enabled && instance.saveFound) {
        instance.saveFound = false;
        Saves.deleteSave(instance.url, "clear");
      }
    }
    if (instance.autoEnabled) {
      Auto.stopAutoTimer(instance, caller);
    }
    instance.enabled = instance.multiEnabled = instance.downloadEnabled = instance.autoEnabled = instance.autoPaused = instance.autoRepeat = instance.shuffleURLs = false;
    instance.autoTimes = instance.autoTimesOriginal;
    instance.multi = {"1": {}, "2": {}, "3": {}};
    instance.multiCount = instance.autoRepeatCount = 0;
    instance.urls = [];
    if (callback) {
      callback(instance);
    } else {
      chrome.runtime.sendMessage({greeting: "updatePopupInstance", instance: instance}, function(response) { if (chrome.runtime.lastError) {} });
    }
    return actionPerformed;
  }

  function returnToStart(caller, instance) {
    let actionPerformed = false;
    if (instance.enabled && instance.startingURL) {
      actionPerformed = true;
      instance.url = instance.startingURL;
      instance.selection = instance.startingSelection;
      instance.selectionStart = instance.startingSelectionStart;
      if (instance.multiEnabled) {
        for (let i = 1; i <= instance.multiCount; i++) {
          instance.multi[i].selection = instance.multi[i].startingSelection;
          instance.multi[i].selectionStart = instance.multi[i].startingSelectionStart;
        }
      }
      if (instance.autoEnabled) {
        instance.autoRepeating = false;
        instance.autoTimes = instance.autoTimesOriginal;
      }
      if (instance.urls && instance.urls.length > 0) {
        instance.urlsCurrentIndex = instance.startingURLsCurrentIndex;
        if (instance.shuffleURLs) {
          instance.urls = [];
          const precalculateProps = IncrementDecrementArray.precalculateURLs(instance);
          instance.urls = precalculateProps.urls;
          instance.urlsCurrentIndex = precalculateProps.currentIndex;
        }
      }
      updateTab(instance);
    }
    return actionPerformed;
  }

  function toolkit(instance) {
    let actionPerformed = true;
    switch (instance.toolkitTool) {
      case "crawl":
        if (chrome.windows && chrome.windows.create) {
          chrome.windows.create({url: chrome.runtime.getURL("/html/popup.html"), type: "popup", width: 550, height: 500}, function(window) {
            instance.tabId = window.tabs[0].id;
            Background.setInstance(instance.tabId, instance);
          });
        } else {
          chrome.runtime.sendMessage({greeting: "crawlPopupNoWindow", instance: instance}, function(response) { if (chrome.runtime.lastError) {} });
        }
        break;
      case "tabs":
        for (const url of instance.urls) {
          chrome.tabs.create({"url": url.urlmod, "active": false});
        }
        break;
    }
    return actionPerformed;
  }

  function auto(instance) {
    let actionPerformed = false;
    if (instance.autoEnabled) {
      Auto.pauseOrResumeAutoTimer(instance);
      instance = Background.getInstance(instance.tabId);
      chrome.runtime.sendMessage({greeting: "updatePopupInstance", instance: instance}, function(response) { if (chrome.runtime.lastError) {} });
      actionPerformed = true;
    }
    return actionPerformed;
  }

  function download(instance, callback) {
    let actionPerformed = false;
    if (instance.downloadEnabled) {
      actionPerformed = true;
      chrome.tabs.executeScript(instance.tabId, {file: "/js/download.js", runAt: "document_end"}, function() {
        const code = "Download.findDownloadURLs(" +
          JSON.stringify(instance.downloadStrategy) + ", " +
          JSON.stringify(instance.downloadExtensions) + ", " +
          JSON.stringify(instance.downloadTags) + ", " +
          JSON.stringify(instance.downloadAttributes) + ", " +
          JSON.stringify(instance.downloadSelector) + ", " +
          JSON.stringify(instance.downloadIncludes) + ", " +
          JSON.stringify(instance.downloadExcludes) + ");";
        chrome.tabs.executeScript(instance.tabId, {code: code, runAt: "document_end"}, function (results) {
          if (results && results[0]) {
            let downloads = results[0];
            if (instance.url === instance.startingURL) {
              if (instance.downloadMSelecteds && instance.downloadMSelecteds.length > 0) {
                downloads.push(...instance.downloadMSelecteds);
              }
              if (instance.downloadMUnselecteds && instance.downloadMUnselecteds.length > 0) {
                downloads = downloads.filter(function(download) {
                  return !instance.downloadMUnselecteds.some(function(munselected) {
                    return download.url === munselected.url;
                  });
                });
              }
            }
            for (const download of downloads) {
              const params = instance.downloadSubfolder && download.filenameAndExtension && download.filename && download.extension ? { url: download.url, filename: instance.downloadSubfolder + "/" + download.filenameAndExtension } : { url: download.url};
              chrome.downloads.download(params, function(downloadId) {
                if (chrome.runtime.lastError && instance.downloadSubfolder) {
                  chrome.downloads.download({url: download.url});
                }
              });
            }
          }
          if (instance.downloadSubfolder) {
            instance.downloadSubfolder = instance.downloadSubfolder.replace(/\d+/, function(match) {
              const matchp1 = (Number(match) + 1) + "";
              return (match.startsWith("0") && match.length > matchp1.length ? ("0".repeat(match.length - matchp1.length)) : "") + matchp1;
            });
            Background.setInstance(instance.tabId, instance);
          }
          if (callback) {
            callback(instance);
          }
        });
      });
    }
    return actionPerformed;
  }

  return {
    performAction: performAction
  };

})();