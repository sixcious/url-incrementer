/**
 * URL Incrementer
 * @file cryptography.js
 * @author Roy Six
 * @license LGPL-3.0
 */

var Cryptography = (() => {

  async function hash(text, salt) {
    const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(text), "PBKDF2", false, ["deriveBits"]);
    const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-512", salt: b642u8a(salt), iterations: 1000 }, key, 512);
    return u8a2b64(new Uint8Array(bits));
  }

  function salt() {
    return u8a2b64(crypto.getRandomValues(new Uint8Array(64)));
  }

  async function encrypt(plaintext) {
    const algorithm = { name: "AES-GCM", iv: crypto.getRandomValues(new Uint8Array(64)) };
    const digest = await crypto.subtle.digest("SHA-256", new Uint8Array([66, 96, 46, 126, 56]));
    const key = await crypto.subtle.importKey("raw", digest, algorithm, false, ["encrypt"]);
    const encryption = await crypto.subtle.encrypt(algorithm, key, new TextEncoder().encode(plaintext));
    return { iv: u8a2b64(algorithm.iv), ciphertext: u8a2b64(new Uint8Array(encryption)) };
  }

  async function decrypt(ciphertext, iv) {
    const algorithm = { name: "AES-GCM", iv: b642u8a(iv) };
    const digest = await crypto.subtle.digest("SHA-256", new Uint8Array([66, 96, 46, 126, 56]));
    const key = await crypto.subtle.importKey("raw", digest, algorithm, false, ["decrypt"]);
    const decryption = await crypto.subtle.decrypt(algorithm, key, b642u8a(ciphertext));
    return new TextDecoder().decode(decryption);
  }

  function u8a2b64(u8a) {
    return btoa(String.fromCharCode(...u8a));
  }

  function b642u8a(b64) {
    return new Uint8Array([...atob(b64)].map(c => c.charCodeAt(0)));
  }

  return {
    hash: hash,
    salt: salt,
    encrypt: encrypt,
    decrypt: decrypt
  };

})();