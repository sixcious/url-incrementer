/**
 * URL Incrementer
 * @file increment-decrement.js
 * @author Roy Six
 * @license LGPL-3.0
 */
 
var IncrementDecrement = (() => {

  function findSelection(url, preference, selectionCustom, previousException) {
    try {
      if (preference === "custom" && selectionCustom) {
        const custom = new RegExp(selectionCustom.pattern, selectionCustom.flags).exec(url);
        if (custom && custom[selectionCustom.group]) { return {selection: custom[selectionCustom.group].substring(selectionCustom.index), selectionStart: custom.index + selectionCustom.index}; }
      }
      if (preference === "prefixes" || preference === "custom") {
        const page = /page=\d+/i.exec(url);
        if (page) { return {selection: page[0].substring(5), selectionStart: page.index + 5}; }
        const terms = /(?:(p|id|next)=\d+)(?!.*(p|id|next)=\d+)/i.exec(url);
        if (terms) { return {selection: terms[0].substring(terms[1].length + 1), selectionStart: terms.index + terms[1].length + 1}; }
        const prefixes = /(?:[=\/]\d+)(?!.*[=\/]\d+)/.exec(url);
        if (prefixes) { return {selection: prefixes[0].substring(1), selectionStart: prefixes.index + 1}; }
      }
      if (preference === "lastnumber" || preference === "prefixes" || preference === "custom") {
        const last = /\d+(?!.*\d+)/.exec(url);
        if (last) { return {selection: last[0], selectionStart: last.index}; }
      }
      if (preference === "firstnumber") {
        const first = /\d+/.exec(url);
        if (first) { return {selection: first[0], selectionStart: first.index}; }
      }
    } catch(e) {
      if (!previousException) { return findSelection(url, "firstnumber", selectionCustom, true); }
    }
    return {selection: "", selectionStart: -1};
  }

  function validateSelection(selection, base, baseCase, baseDateFormat, baseCustom, leadingZeros) {
    let error = "";
    switch (base) {
      case "date":
        const selectionDate = IncrementDecrementDate.incrementDecrementDate("increment", selection, 0, baseDateFormat);
        if (selectionDate !== selection) {
          error = chrome.i18n.getMessage("date_invalid_error");
        }
        break;
      case "custom":
        const selectionCustom = incrementDecrementBaseCustom("increment", selection, 0, baseCustom, leadingZeros);
        if (selectionCustom === "SELECTION_TOO_LARGE!") {
          error = chrome.i18n.getMessage("selection_toolarge_error");
       } else if (selectionCustom !== selection) {
          error = chrome.i18n.getMessage("base_custom_invalid_error");
        }
        break;
      default:
        if (base < 2 || base > 36) {
          error = chrome.i18n.getMessage("base_invalid_error");
        } else if (!/^[a-z0-9]+$/i.test(selection)) {
          error = chrome.i18n.getMessage("selection_notalphanumeric_error");
        } else {
          const selectionInt = parseInt(selection, base);
          const selectionStr = selectionInt.toString(base);
          if (selectionInt >= Number.MAX_SAFE_INTEGER) {
            error = chrome.i18n.getMessage("selection_toolarge_error");
          } else if ((isNaN(selectionInt)) || (selection.toUpperCase() !== ("0".repeat(selection.length > selectionStr.length ? selection.length - selectionStr.length : 0) + selectionStr.toUpperCase()))) {
            error = chrome.i18n.getMessage("selection_base_error");
          }
        }
        break;
    }
    return error;
  }

  function incrementDecrement(action, instance) {
    if (instance.urls && instance.urls.length > 0) {
      IncrementDecrementArray.stepThruURLs(action, instance);
    }
    else if (instance.multiEnabled && !instance.multiRangeEnabled && !/\d/.test(action)) {
      for (let i = 1; i <= instance.multiCount; i++) {
        incrementDecrementURL(action + i, instance);
      }
    }
    else {
      incrementDecrementURL(action, instance);
    }
  }

  function incrementDecrementURL(action, instance) {
    IncrementDecrementMulti.multiPre(action, instance);
    const url = instance.url, selection = instance.selection, selectionStart = instance.selectionStart,
          interval = instance.interval, leadingZeros = instance.leadingZeros,
          base = instance.base, baseCase = instance.baseCase, baseDateFormat = instance.baseDateFormat, baseCustom = instance.baseCustom;
    let selectionmod;
    switch(base) {
      case "date":
        selectionmod = IncrementDecrementDate.incrementDecrementDate(action, selection, interval, baseDateFormat);
        break;
      case "custom":
        selectionmod = incrementDecrementBaseCustom(action, selection, interval, baseCustom, leadingZeros);
        break;
      default:
        selectionmod = incrementDecrementAlphanumeric(action, selection, interval, base, baseCase, leadingZeros);
        break;
    }
    const urlmod = url.substring(0, selectionStart) + selectionmod + url.substring(selectionStart + selection.length);
    IncrementDecrementMulti.multiPost(selectionmod, urlmod, instance);
    instance.url = urlmod;
    instance.selection = selectionmod;
  }

  function incrementDecrementAlphanumeric(action, selection, interval, base, baseCase, leadingZeros) {
    let selectionmod;
    const selectionint = parseInt(selection, base);
    selectionmod = action.startsWith("increment") ? (selectionint + interval <= Number.MAX_SAFE_INTEGER ? selectionint + interval : Number.MAX_SAFE_INTEGER).toString(base) :
                   action.startsWith("decrement") ? (selectionint - interval >= 0 ? selectionint - interval : 0).toString(base) :
                   "";
    if (leadingZeros && selection.length > selectionmod.length) {
      selectionmod = "0".repeat(selection.length - selectionmod.length) + selectionmod;
    }
    if (/[a-z]/i.test(selectionmod)) {
      selectionmod = baseCase === "lowercase" ? selectionmod.toLowerCase() : baseCase === "uppercase" ? selectionmod.toUpperCase() : selectionmod;
    }
    return selectionmod;
  }

  function incrementDecrementBaseCustom(action, selection, interval, alphabet, leadingZeros) {
    let selectionmod = "",
        base = alphabet.length,
        base10num = 0;
    for (let i = selection.length - 1, digit = 0; i >= 0; i--, digit++) {
      const num = alphabet.indexOf(selection[i]);
      base10num += num * (base ** digit);
    }
    if (base10num > Number.MAX_SAFE_INTEGER) {
      return "SELECTION_TOO_LARGE!";
    }
    base10num += action.startsWith("increment") ? interval : -interval;
    if (base10num === 0) {
      selectionmod = alphabet[0];
    } else {
      while (base10num > 0) {
        const remainder = base10num % base;
        selectionmod = `${alphabet[remainder]}${selectionmod}`;
        base10num = Math.floor(base10num / base);
      }
    }
    if (alphabet[0] !== '0' && selection.startsWith(alphabet[0]) && selection.length > selectionmod.length) {
      selectionmod = alphabet[0].repeat(new RegExp("^" + alphabet[0] + "+", "g").exec(selection)[0].length) + selectionmod;
    }
    else if (leadingZeros && selection.startsWith("0") && selection.length > selectionmod.length) {
      selectionmod = "0".repeat(selection.length - selectionmod.length) + selectionmod;
    }
    return selectionmod;
  }

  return {
    findSelection: findSelection,
    validateSelection: validateSelection,
    incrementDecrement: incrementDecrement
  };

})();

var IncrementDecrementMulti = (() => {

  function multiPre(action, instance) {
    if (instance && instance.multiEnabled) {
      const match = /\d+/.exec(action),
            part = match ? match[0] : "";
      instance.multiPart = part;
      instance.selection = instance.multi[part].selection;
      instance.selectionStart = instance.multi[part].selectionStart;
      instance.interval = instance.multi[part].interval;
      instance.base = instance.multi[part].base;
      instance.baseCase = instance.multi[part].baseCase;
      instance.baseDateFormat = instance.multi[part].baseDateFormat;
      instance.leadingZeros = instance.multi[part].leadingZeros;
    }
  }

  function multiPost(selectionmod, urlmod, instance) {
    if (instance && instance.multiEnabled) {
      instance.multi[instance.multiPart].selection = selectionmod;
      const urlLengthDiff = instance.url.length - urlmod.length;
      const thisPartSelectionStart = instance.multi[instance.multiPart].selectionStart;
      for (let i = 1; i <= instance.multiCount; i++) {
        if (i !== instance.multiPart) {
          if (instance.multi[i].selectionStart > thisPartSelectionStart) {
            instance.multi[i].selectionStart = instance.multi[i].selectionStart - urlLengthDiff;
          }
          if (instance.multi[i].selectionStart === thisPartSelectionStart && instance.multi[i].selection.length === instance.multi[instance.multiPart].selection.length + urlLengthDiff) {
            instance.multi[i].selection = selectionmod;
          } else {
            instance.multi[i].selection = urlmod.substring(instance.multi[i].selectionStart, instance.multi[i].selectionStart + instance.multi[i].selection.length);
          }
        }
      }
    }
  }

  return {
    multiPre: multiPre,
    multiPost: multiPost
  };

})();

var IncrementDecrementDate = (() => {

  const mmm = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"],
        mmmm = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"];

  function incrementDecrementDate(action, selection, interval, dateFormat) {
    let selection2 = "";
    try {
      const parts = splitdateparts(selection, dateFormat);
      const date = str2date(parts.strParts, parts.dateFormatParts);
      const date2 = incdecdate(action, date, dateFormat, interval);
      selection2 = date2str(date2, dateFormat, parts.dateFormatParts);
    } catch(e) {
      selection2 = "DateError";
    }
    return selection2;
  }

  function splitdateparts(str, dateFormat) {
    const regexp = /(y+)|(m+)|(Mm+)|(M+)|(d+)|(h+)|(i+)|(l+)|([^ymMdhisl]+)/g;
    const matches = dateFormat.match(regexp);
    let delimiters = "";
    for (const match of matches) {
      if (/^(?![ymMdhisl])/.exec(match)) {
        delimiters += (delimiters ? "|" : "") + match;
      }
    }
    let dateFormatParts = [], strParts = [];
    if (delimiters !== "") {
      const delimitersregexp = new RegExp(delimiters, "g");
      dateFormatParts = dateFormat.split(delimitersregexp).filter(Boolean);
      strParts = str.split(delimitersregexp).filter(Boolean);
    } else {
      dateFormatParts = matches;
      for (let i = 0, currPos = 0; i < dateFormatParts.length; i++) {
        strParts[i] = str.substr(currPos, dateFormatParts[i].length);
        currPos += dateFormatParts[i].length;
      }
    }
    return { "strParts": strParts, "dateFormatParts": dateFormatParts };
  }

  function str2date(strParts, dateFormatParts) {
    const now = new Date();
    const mapParts = new Map([["y", now.getFullYear()], ["m", now.getMonth() + 1], ["d", 15], ["h", 12], ["i", 0], ["s", 0], ["l", 0]]);
    for (let i = 0; i < dateFormatParts.length; i++) {
      switch(dateFormatParts[i]) {
        case "yyyy": mapParts.set("y", strParts[i]); break;
        case "yy":   mapParts.set("y", parseInt(strParts[i]) >= 70 ? "19" + strParts[i] : "20" + strParts[i]); break;
        case "mmmm": case "Mmmm": case"MMMM": mapParts.set("m", mmmm.findIndex(m => m === strParts[i].toLowerCase()) + 1); break;
        case "mmm": case"Mmm": case"MMM": mapParts.set("m", mmm.findIndex(m => m === strParts[i].toLowerCase()) + 1); break;
        case "mm":   mapParts.set("m", strParts[i]); break;
        case "m":    mapParts.set("m", strParts[i]); break;
        case "dd":   mapParts.set("d", strParts[i]); break;
        case "d":    mapParts.set("d", strParts[i]); break;
        case "hh":   mapParts.set("h", strParts[i]); break;
        case "h":    mapParts.set("h", strParts[i]); break;
        case "ii":   mapParts.set("i", strParts[i]); break;
        case "i":    mapParts.set("i", strParts[i]); break;
        case "ss":   mapParts.set("s", strParts[i]); break;
        case "s":    mapParts.set("s", strParts[i]); break;
        case "ll":   mapParts.set("l", strParts[i]); break;
        case "l":    mapParts.set("l", strParts[i]); break;
        default: break;
      }
    }
    return new Date(mapParts.get("y"), mapParts.get("m") - 1, mapParts.get("d"), mapParts.get("h"), mapParts.get("i"), mapParts.get("s"), mapParts.get("l"));
  }

  function incdecdate(action, date, dateFormat, interval) {
    interval = action.startsWith("increment") ? interval : -interval;
    const lowestregexp = /(l|(s|i|h|d|M|m|y(?!.*m))(?!.*M)(?!.*d)(?!.*h)(?!.*i)(?!.*s)(?!.*l))/;
    const lowestmatch = lowestregexp.exec(dateFormat)[0];
    switch(lowestmatch) {
      case "l": date.setMilliseconds(date.getMilliseconds() + interval); break;
      case "s": date.setSeconds(date.getSeconds() + interval); break;
      case "i": date.setMinutes(date.getMinutes() + interval); break;
      case "h": date.setHours(date.getHours() + interval); break;
      case "d": date.setDate(date.getDate() + interval); break;
      case "m": case "M": date = new Date(date.getFullYear(), date.getMonth() + interval); break;
      case "y": date.setFullYear(date.getFullYear() + interval); break;
      default: break;
    }
    return date;
  }

  function date2str(date, dateFormat, dateFormatParts) {
    let str = dateFormat;
    for (let i = 0; i < dateFormatParts.length; i++) {
      switch (dateFormatParts[i]) {
        case "yyyy": str = str.replace(dateFormatParts[i], date.getFullYear()); break;
        case "yy":   str = str.replace(dateFormatParts[i], (date.getFullYear() + "").substring(2)); break;
        case "mmmm": str = str.replace(dateFormatParts[i], mmmm[date.getMonth()]); break;
        case "Mmmm": str = str.replace(dateFormatParts[i], mmmm[date.getMonth()][0].toUpperCase() + mmmm[date.getMonth()].substring(1)); break;
        case "MMMM": str = str.replace(dateFormatParts[i], mmmm[date.getMonth()].toUpperCase()); break;
        case "mmm":  str = str.replace(dateFormatParts[i], mmm[date.getMonth()]); break;
        case "Mmm":  str = str.replace(dateFormatParts[i], mmm[date.getMonth()][0].toUpperCase() + mmm[date.getMonth()].substring(1)); break;
        case "MMM":  str = str.replace(dateFormatParts[i], mmm[date.getMonth()].toUpperCase()); break;
        case "mm":   str = str.replace(dateFormatParts[i], (date.getMonth() + 1) < 10 ? "0" + (date.getMonth() + 1) : (date.getMonth() + 1)); break;
        case "m":    str = str.replace(dateFormatParts[i], date.getMonth() + 1); break;
        case "dd":   str = str.replace(dateFormatParts[i], date.getDate() < 10 ? "0" + date.getDate() : date.getDate()); break;
        case "d":    str = str.replace(dateFormatParts[i], date.getDate()); break;
        case "hh":   str = str.replace(dateFormatParts[i], date.getHours() < 10 ? "0" + date.getHours() : date.getHours()); break;
        case "h":    str = str.replace(dateFormatParts[i], date.getHours()); break;
        case "ii":   str = str.replace(dateFormatParts[i], date.getMinutes() < 10 ? "0" + date.getMinutes() : date.getMinutes()); break;
        case "i":    str = str.replace(dateFormatParts[i], date.getMinutes()); break;
        case "ss":   str = str.replace(dateFormatParts[i], date.getSeconds() < 10 ? "0" + date.getSeconds() : date.getSeconds()); break;
        case "s":    str = str.replace(dateFormatParts[i], date.getSeconds()); break;
        case "ll":   str = str.replace(dateFormatParts[i], "0".repeat(3 - (date.getMilliseconds() + "").length) + date.getMilliseconds()); break;
        case "l":    str = str.replace(dateFormatParts[i], date.getMilliseconds()); break;
        default: break;
      }
    }
    return str;
  }

  return {
    incrementDecrementDate: incrementDecrementDate
  };

})();

var IncrementDecrementArray = (() => {

  function stepThruURLs(action, instance) {
    const urlProps =
      (!instance.autoEnabled && action === "increment") || (action === instance.autoAction) ?
        instance.urls[instance.urlsCurrentIndex + 1 < instance.urls.length ? !instance.autoEnabled ? ++instance.urlsCurrentIndex : instance.urlsCurrentIndex++ : instance.urls.length - 1] :
        instance.urls[instance.urlsCurrentIndex - 1 >= 0 ? !instance.autoEnabled ? --instance.urlsCurrentIndex : instance.urlsCurrentIndex-- : 0];
    instance.url = urlProps.urlmod;
    instance.selection = urlProps.selectionmod;
  }

  function precalculateURLs(instance) {
    let urls = [], currentIndex = 0;
    if (instance.multiRangeEnabled || instance.toolkitEnabled || instance.shuffleURLs) {
      if (instance.toolkitEnabled) {
        urls = buildURLs(instance, instance.toolkitAction, instance.toolkitQuantity);
      } else if (instance.autoEnabled) {
        urls = buildURLs(instance, instance.autoAction, instance.autoTimes);
      } else {
        const shuffleLimit = instance.shuffleLimit;
        const urlsIncrement = buildURLs(instance, "increment", shuffleLimit / 2);
        const urlsDecrement = buildURLs(instance, "decrement", shuffleLimit / 2);
        const urlOriginal = [{"urlmod": instance.url, "selectionmod": instance.selection}];
        currentIndex = urlsDecrement.length;
        urls = [...urlsDecrement, ...urlOriginal, ...urlsIncrement];
      }
    }
    return {"urls": urls, "currentIndex": currentIndex};
  }

  function buildURLs(instance, action, limit) {
    const urls = [],
          url = instance.url,
          selection = instance.selection;
    if (instance.toolkitEnabled && (instance.toolkitTool === "links" || instance.toolkitTool === "crawl")) {
      urls.push({"urlmod": url, "selectionmod": selection});
      limit--;
    }
    if (instance.multiEnabled && instance.multiRangeEnabled) {
      buildMultiRangeURLs(instance, action, urls);
    } else {
      for (let i = 0; i < limit; i++) {
        IncrementDecrement.incrementDecrement(action, instance);
        urls.push({"urlmod": instance.url, "selectionmod": instance.selection});
        if (!isNaN(instance.base)) {
          const selectionint = parseInt(instance.selection, instance.base);
          if (selectionint <= 0 || selectionint >= Number.MAX_SAFE_INTEGER) {
            break;
          }
        }
      }
    }
    if (instance.shuffleURLs) {
      shuffle(urls);
    }
    instance.url = url;
    instance.selection = selection;
    return urls;
  }

  function buildMultiRangeURLs(instance, action, urls) {
    for (let i = 1; i <= instance.multiCount; i++) {
      const urlmod = instance.url.replace(instance.multi[i].range[0], instance.multi[i].range[1]);
      const selectionmod = instance.multi[i].range[1];
      IncrementDecrementMulti.multiPre(action + i, instance);
      IncrementDecrementMulti.multiPost(selectionmod, urlmod, instance);
      instance.multi[i].startingSelectionStart = instance.multi[i].selectionStart;
      instance.url = urlmod;
    }
    urls[0] =  { "urlmod": instance.url, "selectionmod": ""};
    const preurl1 = instance.url;
    for (let i = 0; i < instance.multi[1].times; i++) {
      const press1 = instance.multi[1].selectionStart;
      const press2 = instance.multi[2].selectionStart;
      const press3 = instance.multi[3].selectionStart;
      const preurl2 = instance.url;
      for (let j = 0; j < instance.multi[2].times; j++) {
        const preurl3 = instance.url;
        for (let k = 0; k < instance.multi[3].times - 1; k++) {
          IncrementDecrement.incrementDecrement(action + "3", instance);
          urls.push({"urlmod": instance.url, "selectionmod": instance.selection});
        }
        instance.url = preurl3;
        instance.multi[2].selectionStart = press2;
        if (j !== instance.multi[2].times - 1) {
          IncrementDecrement.incrementDecrement(action + "2", instance);
          urls.push({"urlmod": instance.url, "selectionmod": instance.selection});
        }
        instance.multi[3].selection = instance.multi[3].startingSelection;
      }
      instance.url = preurl2;
      instance.multi[2].selection = instance.multi[2].startingSelection;
      instance.multi[1].selectionStart = press1;
      instance.multi[2].selectionStart = press2;
      instance.multi[3].selectionStart = press3;
      if (i !== instance.multi[1].times - 1) {
        IncrementDecrement.incrementDecrement(action + "1", instance);
        urls.push({"urlmod": instance.url, "selectionmod": instance.selection});
      }
    }
    instance.url = preurl1;
  }

  function shuffle(array) {
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
  }

  return {
    stepThruURLs: stepThruURLs,
    precalculateURLs: precalculateURLs
  };

})();