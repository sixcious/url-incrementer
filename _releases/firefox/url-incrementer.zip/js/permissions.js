/**
 * URL Incrementer
 * @file permissions.js
 * @author Roy Six
 * @license LGPL-3.0
 */
 
var Permissions = (() => {

  const PERMISSIONS = {
    "internalShortcuts": {
      "storageKey": "permissionsInternalShortcuts"
    },
    "download": {
      "storageKey": "permissionsDownload",
      "request": {permissions: ["downloads"]}
    },
    "enhancedMode": {
      "storageKey": "permissionsEnhancedMode"
    }
  };

  function requestPermission(permission, callback) {
    if (!PERMISSIONS[permission].request) {
      chrome.storage.sync.set({[PERMISSIONS[permission].storageKey]: true}, function() {
        if (callback) {
          callback(true);
        }
      });
      return;
    }
    chrome.permissions.request(PERMISSIONS[permission].request, function(granted) {
      if (granted) {
        chrome.storage.sync.set({[PERMISSIONS[permission].storageKey]: true}, function() {
          if (callback) {
            callback(true);
          }
        });
      } else {
        if (callback) {
          callback(false);
        }
      }
    });
  }

  function removePermission(permission, callback) {
    if (!PERMISSIONS[permission].request) {
      chrome.storage.sync.set({[PERMISSIONS[permission].storageKey]: false}, function() {
        if (callback) {
          callback(true);
        }
      });
      return;
    }
    chrome.permissions.remove(PERMISSIONS[permission].request, function(removed) {
      if (removed) {
        chrome.storage.sync.set({[PERMISSIONS[permission].storageKey]: false}, function() {
          if (callback) {
            callback(true);
          }
        });
      }
    });
  }

  function removeAllPermissions(callback) {
    chrome.permissions.remove({ permissions: ["downloads"]}, function(removed) {
      if (removed) {
        if (callback) {
          callback(true);
        }
      }
    });
  }

  function checkDeclarativeContent() {
  }

  return {
    requestPermission: requestPermission,
    removePermission: removePermission,
    removeAllPermissions: removeAllPermissions,
    checkDeclarativeContent: checkDeclarativeContent
  };
})();