/**
 * URL Incrementer
 * @file next-prev.js
 * @author Roy Six
 * @license LGPL-3.0
 */

var NextPrev = (() => {

  const urls = {
    "important":  { "relAttribute": new Map() },
    "attributes": { "equals": new Map(), "startsWith": new Map(), "includes": new Map() },
    "innerHTML":  { "equals": new Map(), "startsWith": new Map(), "includes": new Map() }
  };

  function findNextPrevURL(keywords, priority, sameDomain) {
    const priority2 = priority === "attributes" ? "innerHTML" : "attributes",
          algorithms = [
            { "type": "important", "subtypes": ["relAttribute"] },
            { "type": priority,    "subtypes": ["equals"] },
            { "type": priority2,   "subtypes": ["equals"] },
            { "type": priority,    "subtypes": ["startsWith", "includes"] },
            { "type": priority2,   "subtypes": ["startsWith", "includes"] }
          ];
    buildURLs(keywords, sameDomain);
    for (const algorithm of algorithms) {
      const url = traverseResults(algorithm.type, algorithm.subtypes, keywords);
      if (url) { return url; }
    }
    return "";
  }

  function traverseResults(type, subtypes, keywords) {
    for (const keyword of keywords) {
      for (const subtype of subtypes) {
        if (urls[type][subtype].has(keyword)) {
          return urls[type][subtype].get(keyword);
        }
      }
    }
    return "";
  }

  function buildURLs(keywords, sameDomain) {
    const elements = document.querySelectorAll("link[href], a[href], area[href]"),
          hostname = window.location.hostname;
    for (const element of elements) {
      try {
        const url = new URL(element.href);
        if (sameDomain && url.hostname !== hostname) {
          continue;
        }
        parseText(keywords, "innerHTML", element.href, element.innerHTML.trim().toLowerCase(), "");
        for (const attribute of element.attributes) {
          parseText(keywords, "attributes", element.href, attribute.nodeValue.trim().toLowerCase(), attribute.nodeName.toLowerCase());
        }
      } catch (e) {
      }
    }
  }

  function parseText(keywords, type, href, text, attribute) {
    for (const keyword of keywords) {
      if (attribute && attribute === "rel" && text === keyword) {
        urls.important.relAttribute.set(keyword, href);
      } else if (text === keyword) {
        urls[type].equals.set(keyword, href);
      } else if (text.startsWith(keyword)) {
        urls[type].startsWith.set(keyword, href);
      } else if (text.includes(keyword)) {
        urls[type].includes.set(keyword, href);
      }
    }
  }

  return {
    findNextPrevURL: findNextPrevURL
  };

})();