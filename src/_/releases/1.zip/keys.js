//
//  Copyright (c) 2011 Roy Six
//  http://code.google.com/p/urli/
//  License: LGPL v3.0
//
//  This file is part of urli.
//
//  urli is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  urli is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public License
//  along with urli.  If not, see <http://www.gnu.org/licenses/>.
//

// Global variables.

var keyCodeIncrement;
var keyEventIncrement;
var keyCodeDecrement;
var keyEventDecrement;

// Listen for requests from chrome.extension.sendRequest.

chrome.extension.onRequest.addListener(

	function(request, sender, sendResponse) {

		switch(request.greeting) {

			// From:      background.html
			// Request:   Keys are enabled in options and user clicked accept button in popup form or enabled keys in options.
			// Action:    Add a keyListener.
			// Callback:  None.

			case "addKeyListener":
				window.addEventListener("keyup", keyListener, false);
				sendResponse({});
				break;

			// From:      background.html
			// Request:   User clicked the Clear button from popup or disabled keys in options.
			// Action:    Remove the keyListener.
			// Callback:  None.

			case "removeKeyListener":
				window.removeEventListener("keyup", keyListener, false);
				sendResponse({});
				break;

			// From:      background.html
			// Request:   User changed the keys for Increment and Decrement in options.
			// Action:    Update the global variables holding the user-defined keyCodes/keyEvents to the new key settings.
			// Callback:  None.

			case "updateKeys":
				keyCodeIncrement = request.keyCodeIncrement;
				keyEventIncrement = request.keyEventIncrement;
				keyCodeDecrement = request.keyCodeDecrement;
				keyEventDecrement = request.keyEventDecrement;
				sendResponse({});
				break;

			// Unspecified request -- should not be needed!

			default:
				sendResponse({});
				break;
		}

	}

);

// When a listener is added, this function executes on each keyup event.

function keyListener(keyEvent) {

	// Increment.

	if ((keyEventIncrement == " Alt" && keyEvent.altKey && keyEvent.keyCode == keyCodeIncrement)     ||
	    (keyEventIncrement == " Ctrl" && keyEvent.ctrlKey && keyEvent.keyCode == keyCodeIncrement)   ||
	    (keyEventIncrement == " Shift" && keyEvent.shiftKey && keyEvent.keyCode == keyCodeIncrement) ||
	    (keyEventIncrement == " " && keyEvent.keyCode == keyCodeIncrement)) {

		chrome.extension.sendRequest({greeting: "modifyUrliAndUpdateTab", action: "Increment"}, function() {});
	}

	// Decrement.

	else if ((keyEventDecrement == " Alt" && keyEvent.altKey && keyEvent.keyCode == keyCodeDecrement)     ||
	         (keyEventDecrement == " Ctrl" && keyEvent.ctrlKey && keyEvent.keyCode == keyCodeDecrement)   ||
	         (keyEventDecrement == " Shift" && keyEvent.shiftKey && keyEvent.keyCode == keyCodeDecrement) ||
	         (keyEventDecrement == " " && keyEvent.keyCode == keyCodeDecrement)) {

		chrome.extension.sendRequest({greeting: "modifyUrliAndUpdateTab", action: "Decrement"}, function() {});
	}
}
